# 12Labs - AI Voiceover App

## Project Structure

```
12labs/
├── backend/          # FastAPI Python backend
│   ├── app/
│   │   ├── main.py
│   │   ├── config.py
│   │   ├── database.py
│   │   ├── models/
│   │   ├── routers/
│   │   ├── services/
│   │   │   ├── emotion_parser.py   ← Core emotion tag engine
│   │   │   ├── elevenlabs.py       ← TTS provider integration
│   │   │   ├── audio_processor.py  ← Chunking + stitching (ffmpeg)
│   │   │   ├── storage.py          ← S3-compatible storage
│   │   │   └── usage_tracker.py    ← Usage limits
│   │   └── middleware/
│   ├── migrations/init.sql
│   ├── requirements.txt
│   ├── Dockerfile
│   ├── docker-compose.yml
│   └── .env.example
└── android/          # Kotlin + Jetpack Compose Android app
    ├── app/src/main/java/com/twelvelabs/app/
    │   ├── MainActivity.kt
    │   ├── TwelveLabsApp.kt
    │   ├── di/                     ← Hilt DI modules
    │   ├── data/
    │   │   ├── remote/             ← Retrofit API + Auth interceptor
    │   │   ├── local/              ← Room DB cache
    │   │   └── repository/         ← Single source of truth
    │   ├── domain/model/           ← App data models
    │   └── ui/
    │       ├── home/               ← Script editor + generate
    │       ├── voices/             ← Voice cards + preview
    │       ├── projects/           ← Project history
    │       ├── player/             ← Audio player sheet
    │       ├── settings/
    │       ├── navigation/
    │       ├── components/
    │       └── theme/              ← 12Labs dark theme
    └── build.gradle.kts
```

## Quick Start

### Backend
```bash
cd backend
cp .env.example .env
# Fill in: ELEVENLABS_API_KEY, Firebase credentials, S3 details
docker-compose up
```

The backend runs on port 8000.
API docs (debug mode): http://localhost:8000/docs

### Adding Voices
Insert voice records directly into the `voices` table:
```sql
INSERT INTO voices (display_name, description, accent, provider, provider_voice_id, voice_settings, tier_required, sort_order)
VALUES (
  'Documentary Voice',
  'Deep, authoritative narrator',
  'American',
  'elevenlabs',
  'YOUR_ELEVENLABS_VOICE_ID_HERE',
  '{"stability": 0.75, "similarity_boost": 0.85, "style": 0.0, "use_speaker_boost": true}',
  'free',
  1
);
```

For the preview audio: upload the preview MP3 to S3 at path `voices/previews/{voice_uuid}/preview.mp3`, then update `preview_storage_path` in the voices table.

The Android app automatically picks up voice changes — no rebuild needed.

### Android App
1. Open `android/` in Android Studio Hedgehog or newer
2. Create `google-services.json` from Firebase console, place in `app/`
3. Update `BuildConfig.API_BASE_URL` in `app/build.gradle.kts` to your backend URL
4. Run on device/emulator (minSdk 26)

## Architecture
- **Android → Backend**: HTTPS + Firebase JWT (never API keys in APK)
- **Backend → ElevenLabs**: Server-side only, API key in env var
- **Audio storage**: S3 signed URLs (expire in 15 min by default)
- **Usage tracking**: Calculated server-side; client values ignored
- **Voice config**: Backend DB only; provider_voice_id never sent to app

## Emotion Tag Support (ElevenLabs)
| Tag | Support | Method |
|-----|---------|--------|
| [pause] / [short pause] / [long pause] | ✅ Native | SSML break |
| [whispers] / [softly] / [quietly] | ⚠️ Approximated | Voice settings override |
| [excited] / [dramatic] / [angry] | ⚠️ Approximated | Style + stability tuning |
| [chuckles] / [sighs] / [gasps] | ❌ Fallback | Silence inserted |

## Voice Management
Add/remove/update voices from the backend DB anytime.
The Android app fetches voices on every app open — no rebuild needed.
Provider Voice IDs are NEVER sent to the Android client.

## Security
- API keys: backend env vars only
- Auth: Firebase JWT, verified server-side on every request
- Audio URLs: pre-signed, expire in 15 minutes
- Rate limiting: per-user, configurable
- Input sanitization: all script inputs sanitized
- Usage: server-calculated, client values ignored
