import os

def w(path, content):
    full = f'/data/12labs/android/{path}'
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, 'w') as f:
        f.write(content)
    print(f'wrote {path}')

BASE = 'app/src/main/java/com/twelvelabs/app'

# ── Data Models ─────────────────────────────────────────────────────────────
w(f'{BASE}/domain/model/Models.kt', '''
package com.twelvelabs.app.domain.model

import java.util.Date

data class Voice(
    val id: String,
    val displayName: String,
    val description: String?,
    val accent: String?,
    val tierRequired: String,
    val previewUrl: String?,
)

data class Project(
    val id: String,
    val name: String,
    val script: String,
    val voiceId: String?,
    val speed: Float,
    val audioFormat: String,
    val status: String,        // draft | generating | done | failed
    val audioUrl: String?,
    val audioDurationSeconds: Float?,
    val charsUsed: Int?,
    val createdAt: Date?,
    val updatedAt: Date?,
)

data class UsageInfo(
    val charsUsed: Int,
    val charsLimit: Int,
    val subscriptionTier: String,
    val formatsAvailable: List<String>,
)

data class GenerationJob(
    val jobId: String,
    val status: String,
    val progress: Float,
    val audioUrl: String?,
    val error: String?,
)

data class PronunciationRule(
    val id: String,
    val word: String,
    val pronunciation: String,
)

enum class EmotionCategory(val label: String) {
    VOCAL_ACTIONS("Vocal Actions"),
    DELIVERY("Delivery"),
    EMOTIONS("Emotions"),
    PAUSES("Pauses"),
}

data class EmotionTag(
    val tag: String,
    val category: EmotionCategory,
)

val ALL_EMOTION_TAGS = listOf(
    // Vocal Actions
    EmotionTag("chuckles",      EmotionCategory.VOCAL_ACTIONS),
    EmotionTag("laughs",        EmotionCategory.VOCAL_ACTIONS),
    EmotionTag("laughs softly", EmotionCategory.VOCAL_ACTIONS),
    EmotionTag("sighs",         EmotionCategory.VOCAL_ACTIONS),
    EmotionTag("gasps",         EmotionCategory.VOCAL_ACTIONS),
    EmotionTag("deep breath",   EmotionCategory.VOCAL_ACTIONS),
    EmotionTag("clears throat", EmotionCategory.VOCAL_ACTIONS),
    // Delivery
    EmotionTag("whispers",      EmotionCategory.DELIVERY),
    EmotionTag("softly",        EmotionCategory.DELIVERY),
    EmotionTag("quietly",       EmotionCategory.DELIVERY),
    EmotionTag("slowly",        EmotionCategory.DELIVERY),
    EmotionTag("firmly",        EmotionCategory.DELIVERY),
    EmotionTag("dramatically",  EmotionCategory.DELIVERY),
    // Emotions
    EmotionTag("happy",         EmotionCategory.EMOTIONS),
    EmotionTag("sad",           EmotionCategory.EMOTIONS),
    EmotionTag("angry",         EmotionCategory.EMOTIONS),
    EmotionTag("excited",       EmotionCategory.EMOTIONS),
    EmotionTag("nervous",       EmotionCategory.EMOTIONS),
    EmotionTag("scared",        EmotionCategory.EMOTIONS),
    EmotionTag("confused",      EmotionCategory.EMOTIONS),
    EmotionTag("shocked",       EmotionCategory.EMOTIONS),
    EmotionTag("serious",       EmotionCategory.EMOTIONS),
    EmotionTag("calm",          EmotionCategory.EMOTIONS),
    EmotionTag("concerned",     EmotionCategory.EMOTIONS),
    // Pauses
    EmotionTag("pause",         EmotionCategory.PAUSES),
    EmotionTag("short pause",   EmotionCategory.PAUSES),
    EmotionTag("long pause",    EmotionCategory.PAUSES),
)
''')

# ── Remote API DTOs ────────────────────────────────────────────────────────
w(f'{BASE}/data/remote/models/ApiModels.kt', '''
package com.twelvelabs.app.data.remote.models

import com.google.gson.annotations.SerializedName

data class VoiceDto(
    val id: String,
    @SerializedName("display_name") val displayName: String,
    val description: String?,
    val accent: String?,
    @SerializedName("tier_required") val tierRequired: String,
    @SerializedName("preview_url") val previewUrl: String?,
)

data class ProjectDto(
    val id: String,
    val name: String,
    val script: String,
    @SerializedName("voice_id") val voiceId: String?,
    val speed: Float,
    @SerializedName("audio_format") val audioFormat: String,
    val status: String,
    @SerializedName("audio_url") val audioUrl: String?,
    @SerializedName("audio_duration_seconds") val audioDurationSeconds: Float?,
    @SerializedName("chars_used") val charsUsed: Int?,
    @SerializedName("created_at") val createdAt: String?,
    @SerializedName("updated_at") val updatedAt: String?,
)

data class CreateProjectRequest(
    val name: String = "Untitled Project",
    val script: String = "",
    @SerializedName("voice_id") val voiceId: String? = null,
    val speed: Float = 1.0f,
    @SerializedName("audio_format") val audioFormat: String = "mp3",
)

data class UpdateProjectRequest(
    val name: String? = null,
    val script: String? = null,
    @SerializedName("voice_id") val voiceId: String? = null,
    val speed: Float? = null,
)

data class GenerateRequest(
    @SerializedName("project_id") val projectId: String,
    @SerializedName("voice_id") val voiceId: String,
    val script: String,
    val speed: Float = 1.0f,
    @SerializedName("audio_format") val audioFormat: String = "mp3",
    @SerializedName("voice_settings_override") val voiceSettingsOverride: Map<String, Any>? = null,
)

data class GenerateResponse(
    @SerializedName("job_id") val jobId: String,
    val status: String,
    val message: String,
)

data class JobStatusResponse(
    @SerializedName("job_id") val jobId: String,
    val status: String,
    val progress: Float,
    @SerializedName("audio_url") val audioUrl: String?,
    val error: String?,
)

data class UsageDto(
    @SerializedName("chars_used") val charsUsed: Int,
    @SerializedName("chars_limit") val charsLimit: Int,
    @SerializedName("subscription_tier") val subscriptionTier: String,
    @SerializedName("formats_available") val formatsAvailable: List<String>,
)

data class PronunciationRuleDto(
    val id: String,
    val word: String,
    val pronunciation: String,
)

data class CreatePronunciationRequest(val word: String, val pronunciation: String)

data class MeResponse(
    val id: String,
    val email: String?,
    @SerializedName("display_name") val displayName: String?,
    @SerializedName("subscription_tier") val subscriptionTier: String,
)
''')

# ── API Service ────────────────────────────────────────────────────────────
w(f'{BASE}/data/remote/ApiService.kt', '''
package com.twelvelabs.app.data.remote

import com.twelvelabs.app.data.remote.models.*
import retrofit2.Response
import retrofit2.http.*

interface ApiService {
    // Auth
    @GET("auth/me")
    suspend fun getMe(): Response<MeResponse>

    // Voices
    @GET("voices")
    suspend fun getVoices(): Response<List<VoiceDto>>

    // Projects
    @GET("projects")
    suspend fun getProjects(
        @Query("limit") limit: Int = 50,
        @Query("offset") offset: Int = 0,
    ): Response<List<ProjectDto>>

    @POST("projects")
    suspend fun createProject(@Body body: CreateProjectRequest): Response<ProjectDto>

    @GET("projects/{id}")
    suspend fun getProject(@Path("id") id: String): Response<ProjectDto>

    @PUT("projects/{id}")
    suspend fun updateProject(@Path("id") id: String, @Body body: UpdateProjectRequest): Response<ProjectDto>

    @DELETE("projects/{id}")
    suspend fun deleteProject(@Path("id") id: String): Response<Unit>

    @POST("projects/{id}/duplicate")
    suspend fun duplicateProject(@Path("id") id: String): Response<ProjectDto>

    // Generation
    @POST("generate")
    suspend fun startGeneration(@Body body: GenerateRequest): Response<GenerateResponse>

    @GET("generate/{jobId}/status")
    suspend fun getJobStatus(@Path("jobId") jobId: String): Response<JobStatusResponse>

    // Usage
    @GET("usage/me")
    suspend fun getUsage(): Response<UsageDto>

    // Pronunciation
    @GET("pronunciation")
    suspend fun getPronunciationRules(): Response<List<PronunciationRuleDto>>

    @POST("pronunciation")
    suspend fun createPronunciationRule(@Body body: CreatePronunciationRequest): Response<PronunciationRuleDto>

    @DELETE("pronunciation/{id}")
    suspend fun deletePronunciationRule(@Path("id") id: String): Response<Unit>
}
''')

# ── Auth Interceptor ──────────────────────────────────────────────────────
w(f'{BASE}/data/remote/AuthInterceptor.kt', '''
package com.twelvelabs.app.data.remote

import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.tasks.await
import okhttp3.Interceptor
import okhttp3.Response

class AuthInterceptor(private val auth: FirebaseAuth) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val user = auth.currentUser ?: return chain.proceed(chain.request())
        val token = runBlocking {
            try { user.getIdToken(false).await()?.token } catch (e: Exception) { null }
        } ?: return chain.proceed(chain.request())

        val request = chain.request().newBuilder()
            .addHeader("Authorization", "Bearer $token")
            .build()
        return chain.proceed(request)
    }
}
''')

# ── DI Modules ────────────────────────────────────────────────────────────
w(f'{BASE}/di/AppModule.kt', '''
package com.twelvelabs.app.di

import android.content.Context
import androidx.room.Room
import com.twelvelabs.app.data.local.AppDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides @Singleton
    fun provideDatabase(@ApplicationContext ctx: Context): AppDatabase =
        Room.databaseBuilder(ctx, AppDatabase::class.java, "twelvelabs.db")
            .fallbackToDestructiveMigration()
            .build()
}
''')

w(f'{BASE}/di/NetworkModule.kt', '''
package com.twelvelabs.app.di

import com.google.firebase.auth.FirebaseAuth
import com.twelvelabs.app.BuildConfig
import com.twelvelabs.app.data.remote.ApiService
import com.twelvelabs.app.data.remote.AuthInterceptor
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {
    @Provides @Singleton
    fun provideFirebaseAuth(): FirebaseAuth = FirebaseAuth.getInstance()

    @Provides @Singleton
    fun provideOkHttpClient(auth: FirebaseAuth): OkHttpClient =
        OkHttpClient.Builder()
            .addInterceptor(AuthInterceptor(auth))
            .addInterceptor(HttpLoggingInterceptor().apply {
                level = if (BuildConfig.DEBUG)
                    HttpLoggingInterceptor.Level.BODY
                else HttpLoggingInterceptor.Level.NONE
            })
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()

    @Provides @Singleton
    fun provideRetrofit(client: OkHttpClient): Retrofit =
        Retrofit.Builder()
            .baseUrl(BuildConfig.API_BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

    @Provides @Singleton
    fun provideApiService(retrofit: Retrofit): ApiService =
        retrofit.create(ApiService::class.java)
}
''')

# ── Local Room DB ─────────────────────────────────────────────────────────
w(f'{BASE}/data/local/AppDatabase.kt', '''
package com.twelvelabs.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.twelvelabs.app.data.local.entities.ProjectEntity
import com.twelvelabs.app.data.local.dao.ProjectDao

@Database(entities = [ProjectEntity::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
}
''')

w(f'{BASE}/data/local/Converters.kt', '''
package com.twelvelabs.app.data.local

import androidx.room.TypeConverter
import java.util.Date

class Converters {
    @TypeConverter fun fromTimestamp(value: Long?): Date? = value?.let { Date(it) }
    @TypeConverter fun dateToTimestamp(date: Date?): Long? = date?.time
}
''')

w(f'{BASE}/data/local/entities/ProjectEntity.kt', '''
package com.twelvelabs.app.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val script: String,
    val voiceId: String?,
    val speed: Float,
    val audioFormat: String,
    val status: String,
    val audioUrl: String?,
    val audioDurationSeconds: Float?,
    val charsUsed: Int?,
    val createdAt: Date?,
    val updatedAt: Date?,
)
''')

w(f'{BASE}/data/local/dao/ProjectDao.kt', '''
package com.twelvelabs.app.data.local.dao

import androidx.room.*
import com.twelvelabs.app.data.local.entities.ProjectEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun getById(id: String): ProjectEntity?

    @Upsert
    suspend fun upsert(project: ProjectEntity)

    @Upsert
    suspend fun upsertAll(projects: List<ProjectEntity>)

    @Delete
    suspend fun delete(project: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteById(id: String)
}
''')

# ── Repository ────────────────────────────────────────────────────────────
w(f'{BASE}/data/repository/VoiceRepository.kt', '''
package com.twelvelabs.app.data.repository

import com.twelvelabs.app.data.remote.ApiService
import com.twelvelabs.app.domain.model.Voice
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class VoiceRepository @Inject constructor(private val api: ApiService) {
    suspend fun getVoices(): Result<List<Voice>> = withContext(Dispatchers.IO) {
        runCatching {
            val resp = api.getVoices()
            if (resp.isSuccessful) {
                resp.body()!!.map {
                    Voice(it.id, it.displayName, it.description, it.accent, it.tierRequired, it.previewUrl)
                }
            } else error("Failed to load voices: ${resp.code()}")
        }
    }
}
''')

w(f'{BASE}/data/repository/ProjectRepository.kt', '''
package com.twelvelabs.app.data.repository

import com.twelvelabs.app.data.local.dao.ProjectDao
import com.twelvelabs.app.data.local.entities.ProjectEntity
import com.twelvelabs.app.data.remote.ApiService
import com.twelvelabs.app.data.remote.models.*
import com.twelvelabs.app.domain.model.Project
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ProjectRepository @Inject constructor(
    private val api: ApiService,
    private val dao: ProjectDao,
) {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)

    fun observeProjects(): Flow<List<Project>> = dao.observeAll().map { list ->
        list.map { it.toDomain() }
    }

    suspend fun syncProjects(): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val resp = api.getProjects()
            if (resp.isSuccessful) {
                val entities = resp.body()!!.map { it.toEntity() }
                dao.upsertAll(entities)
            } else error("Sync failed: ${resp.code()}")
        }
    }

    suspend fun createProject(name: String = "Untitled Project"): Result<Project> = withContext(Dispatchers.IO) {
        runCatching {
            val resp = api.createProject(CreateProjectRequest(name = name))
            if (resp.isSuccessful) {
                val entity = resp.body()!!.toEntity()
                dao.upsert(entity)
                entity.toDomain()
            } else error("Create failed: ${resp.code()}")
        }
    }

    suspend fun updateProject(id: String, name: String? = null, script: String? = null, voiceId: String? = null, speed: Float? = null): Result<Project> = withContext(Dispatchers.IO) {
        runCatching {
            val resp = api.updateProject(id, UpdateProjectRequest(name, script, voiceId, speed))
            if (resp.isSuccessful) {
                val entity = resp.body()!!.toEntity()
                dao.upsert(entity)
                entity.toDomain()
            } else error("Update failed: ${resp.code()}")
        }
    }

    suspend fun deleteProject(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            api.deleteProject(id)
            dao.deleteById(id)
        }
    }

    suspend fun duplicateProject(id: String): Result<Project> = withContext(Dispatchers.IO) {
        runCatching {
            val resp = api.duplicateProject(id)
            if (resp.isSuccessful) {
                val entity = resp.body()!!.toEntity()
                dao.upsert(entity)
                entity.toDomain()
            } else error("Duplicate failed: ${resp.code()}")
        }
    }

    private fun ProjectDto.toEntity() = ProjectEntity(
        id, name, script, voiceId, speed, audioFormat, status, audioUrl,
        audioDurationSeconds, charsUsed,
        runCatching { createdAt?.let { dateFormat.parse(it.take(19)) } }.getOrNull(),
        runCatching { updatedAt?.let { dateFormat.parse(it.take(19)) } }.getOrNull(),
    )

    private fun ProjectEntity.toDomain() = Project(
        id, name, script, voiceId, speed, audioFormat, status,
        audioUrl, audioDurationSeconds, charsUsed, createdAt, updatedAt
    )
}
''')

w(f'{BASE}/data/repository/GenerationRepository.kt', '''
package com.twelvelabs.app.data.repository

import com.twelvelabs.app.data.remote.ApiService
import com.twelvelabs.app.data.remote.models.GenerateRequest
import com.twelvelabs.app.domain.model.GenerationJob
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GenerationRepository @Inject constructor(private val api: ApiService) {

    suspend fun startGeneration(
        projectId: String,
        voiceId: String,
        script: String,
        speed: Float = 1.0f,
        audioFormat: String = "mp3",
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val resp = api.startGeneration(
                GenerateRequest(projectId, voiceId, script, speed, audioFormat)
            )
            if (resp.isSuccessful) resp.body()!!.jobId
            else {
                val code = resp.code()
                val msg = when (code) {
                    402 -> "Character limit exceeded. Upgrade for more."
                    403 -> "This voice or format requires a higher plan."
                    429 -> "Too many requests. Please wait and try again."
                    else -> "Voice generation failed. Please try again."
                }
                error(msg)
            }
        }
    }

    fun pollJobStatus(jobId: String): Flow<GenerationJob> = flow {
        var done = false
        var retries = 0
        while (!done && retries < 120) {
            val resp = runCatching { api.getJobStatus(jobId) }.getOrNull()
            if (resp?.isSuccessful == true) {
                val body = resp.body()!!
                emit(GenerationJob(body.jobId, body.status, body.progress, body.audioUrl, body.error))
                if (body.status == "done" || body.status == "failed") done = true
            }
            if (!done) delay(2000)
            retries++
        }
    }
}
''')

print('data layer done')
