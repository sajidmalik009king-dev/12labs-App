# 12Labs — Build the APK

The sandbox that prepared this project has **no Android SDK and no network access**,
so the APK could not be compiled there. Everything that blocked the build has been
fixed; the steps below produce the APK on your machine.

## What was broken and is now fixed
1. `app/build.gradle.kts` — `buildConfigField` used a single-quoted literal, which is
   invalid in the Kotlin DSL. The build script could not even be evaluated.
2. `AndroidManifest.xml` — used `tools:node="remove"` without declaring
   `xmlns:tools`. Manifest merge failed.
3. Launcher icons `@mipmap/ic_launcher` / `ic_launcher_round` did not exist.
   Generated for all densities plus adaptive icons and `values/colors.xml`.
4. `HomeScreen.kt` — the editor placeholder was a double-quoted string containing raw
   newlines (unterminated literal).
5. `HomeViewModel.kt` — `"\s+"` written as `"\s+"` with a single backslash is an
   illegal Kotlin escape.
6. `EmotionPicker.kt` — imported `com.google.accompanist.flowlayout.FlowRow`, a package
   that does not exist. Now uses Compose `FlowRow` with `ExperimentalLayoutApi`.
7. `AudioPlayerSheet.kt` — a truncated import line (`imx.coroutines.isActive`) plus a
   duplicate import.
8. Missing dependencies: `lifecycle-runtime-compose` (needed by
   `collectAsStateWithLifecycle`) and `kotlinx-coroutines-play-services` (needed by
   `Task.await()` in `AuthInterceptor`).
9. `gradle.properties` was missing entirely — `android.useAndroidX=true` is mandatory.
10. `gradle/wrapper/gradle-wrapper.properties` added (Gradle 8.9, matches AGP 8.5.2).
11. `google-services` plugin is now applied only when `app/google-services.json`
    exists, so the build no longer fails outright without Firebase config.
12. Release build type now has a signing config, so `app-release.apk` is installable.
13. Debug-only network security config added for `10.0.2.2` / `localhost` testing.

Nothing else was changed. Voice system, voice IDs, previews, script editor, emotion
parser, ElevenLabs integration, audio processing, projects/history, backend API, auth,
usage tracking and pronunciation rules are untouched.

## Requirements
- JDK 17 (AGP 8.5.2 does not support JDK 21+ reliably; do not use JDK 25)
- Android SDK Platform 35 + Build-Tools 35.0.0
- Android Studio Koala or newer (recommended), or standalone Gradle 8.9

## Steps (Android Studio — easiest)
1. `File > Open` and select the **`android/`** folder (not the repo root).
2. Let Studio create the Gradle wrapper JAR and sync.
3. `File > Project Structure > SDK Location` — set JDK 17.
4. Copy `local.properties.example` to `local.properties` and set `API_BASE_URL`.
5. Put `google-services.json` into `android/app/` (Firebase console > your Android app,
   package name `com.twelvelabs.app`). Without it, Firebase Auth is disabled at runtime.
6. `Build > Build Bundle(s)/APK(s) > Build APK(s)`.

## Steps (command line)
```bash
cd android
# one-time: create the wrapper JAR (needs a local Gradle 8.9 install)
gradle wrapper --gradle-version 8.9

export JAVA_HOME=/path/to/jdk-17
./gradlew clean :app:assembleDebug
./gradlew :app:assembleRelease
```

## Expected output paths
- Debug: `android/app/build/outputs/apk/debug/app-debug.apk`
- Release: `android/app/build/outputs/apk/release/app-release.apk`

Rename either to `12Labs.apk` and sideload it. Verify with:
```bash
aapt2 dump badging app/build/outputs/apk/debug/app-debug.apk | head
# expect: package: name='com.twelvelabs.app' versionCode='1' versionName='1.0.0'
#         application-label:'12Labs'
```

## Credentials you must supply (never in the APK)
| Credential | Where |
|---|---|
| `ELEVENLABS_API_KEY` | `backend/.env` — server side only |
| `FIREBASE_PROJECT_ID`, `FIREBASE_SERVICE_ACCOUNT_JSON` | `backend/.env` |
| `S3_ACCESS_KEY`, `S3_SECRET_KEY`, `S3_BUCKET`, `S3_REGION` | `backend/.env` |
| `DATABASE_URL`, `REDIS_URL`, `SECRET_KEY` | `backend/.env` |
| `google-services.json` | `android/app/google-services.json` |
| `API_BASE_URL` | `android/local.properties` |

## Your voices
No voice IDs are present anywhere in the ZIP — they live in the backend `voices`
table (`provider_voice_id`), and the API deliberately never sends them to the app.
The 26 MP3 previews you attached are not in the project; upload each to
`voices/previews/{voice_uuid}/preview.mp3` in your bucket and set
`preview_storage_path` on the matching row, per `README.md`. No placeholder or
invented voices were added.
