
package com.twelvelabs.app.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val script: String,
    val voiceId: String?,
    val speed: Float,
    val audioFormat: String,
    val status: String,
    val audioUrl: String?,
    val audioDurationSeconds: Float?,
    val charsUsed: Int?,
    val createdAt: Date?,
    val updatedAt: Date?,
)
