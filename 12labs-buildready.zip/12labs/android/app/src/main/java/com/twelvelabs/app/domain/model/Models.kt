
package com.twelvelabs.app.domain.model

import java.util.Date

data class Voice(
    val id: String,
    val displayName: String,
    val description: String?,
    val accent: String?,
    val tierRequired: String,
    val previewUrl: String?,
)

data class Project(
    val id: String,
    val name: String,
    val script: String,
    val voiceId: String?,
    val speed: Float,
    val audioFormat: String,
    val status: String,        // draft | generating | done | failed
    val audioUrl: String?,
    val audioDurationSeconds: Float?,
    val charsUsed: Int?,
    val createdAt: Date?,
    val updatedAt: Date?,
)

data class UsageInfo(
    val charsUsed: Int,
    val charsLimit: Int,
    val subscriptionTier: String,
    val formatsAvailable: List<String>,
)

data class GenerationJob(
    val jobId: String,
    val status: String,
    val progress: Float,
    val audioUrl: String?,
    val error: String?,
)

data class PronunciationRule(
    val id: String,
    val word: String,
    val pronunciation: String,
)

enum class EmotionCategory(val label: String) {
    VOCAL_ACTIONS("Vocal Actions"),
    DELIVERY("Delivery"),
    EMOTIONS("Emotions"),
    PAUSES("Pauses"),
}

data class EmotionTag(
    val tag: String,
    val category: EmotionCategory,
)

val ALL_EMOTION_TAGS = listOf(
    // Vocal Actions
    EmotionTag("chuckles",      EmotionCategory.VOCAL_ACTIONS),
    EmotionTag("laughs",        EmotionCategory.VOCAL_ACTIONS),
    EmotionTag("laughs softly", EmotionCategory.VOCAL_ACTIONS),
    EmotionTag("sighs",         EmotionCategory.VOCAL_ACTIONS),
    EmotionTag("gasps",         EmotionCategory.VOCAL_ACTIONS),
    EmotionTag("deep breath",   EmotionCategory.VOCAL_ACTIONS),
    EmotionTag("clears throat", EmotionCategory.VOCAL_ACTIONS),
    // Delivery
    EmotionTag("whispers",      EmotionCategory.DELIVERY),
    EmotionTag("softly",        EmotionCategory.DELIVERY),
    EmotionTag("quietly",       EmotionCategory.DELIVERY),
    EmotionTag("slowly",        EmotionCategory.DELIVERY),
    EmotionTag("firmly",        EmotionCategory.DELIVERY),
    EmotionTag("dramatically",  EmotionCategory.DELIVERY),
    // Emotions
    EmotionTag("happy",         EmotionCategory.EMOTIONS),
    EmotionTag("sad",           EmotionCategory.EMOTIONS),
    EmotionTag("angry",         EmotionCategory.EMOTIONS),
    EmotionTag("excited",       EmotionCategory.EMOTIONS),
    EmotionTag("nervous",       EmotionCategory.EMOTIONS),
    EmotionTag("scared",        EmotionCategory.EMOTIONS),
    EmotionTag("confused",      EmotionCategory.EMOTIONS),
    EmotionTag("shocked",       EmotionCategory.EMOTIONS),
    EmotionTag("serious",       EmotionCategory.EMOTIONS),
    EmotionTag("calm",          EmotionCategory.EMOTIONS),
    EmotionTag("concerned",     EmotionCategory.EMOTIONS),
    // Pauses
    EmotionTag("pause",         EmotionCategory.PAUSES),
    EmotionTag("short pause",   EmotionCategory.PAUSES),
    EmotionTag("long pause",    EmotionCategory.PAUSES),
)
