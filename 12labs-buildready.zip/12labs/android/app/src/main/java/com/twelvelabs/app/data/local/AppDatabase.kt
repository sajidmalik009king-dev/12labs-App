
package com.twelvelabs.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.twelvelabs.app.data.local.entities.ProjectEntity
import com.twelvelabs.app.data.local.dao.ProjectDao

@Database(entities = [ProjectEntity::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
}
