
package com.twelvelabs.app.ui.voices

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.twelvelabs.app.data.repository.VoiceRepository
import com.twelvelabs.app.domain.model.Voice
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class VoicesUiState(
    val voices: List<Voice> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val playingVoiceId: String? = null,
    val selectedVoiceId: String? = null,
)

@HiltViewModel
class VoicesViewModel @Inject constructor(
    private val voiceRepo: VoiceRepository,
) : ViewModel() {
    private val _uiState = MutableStateFlow(VoicesUiState())
    val uiState: StateFlow<VoicesUiState> = _uiState.asStateFlow()

    init { loadVoices() }

    fun loadVoices() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            voiceRepo.getVoices()
                .onSuccess { voices -> _uiState.update { it.copy(voices = voices, isLoading = false) } }
                .onFailure { e -> _uiState.update { it.copy(isLoading = false, error = "Failed to load voices.") } }
        }
    }

    fun selectVoice(voiceId: String) {
        _uiState.update { it.copy(selectedVoiceId = voiceId) }
    }

    fun setPlayingVoice(voiceId: String?) {
        _uiState.update { it.copy(playingVoiceId = voiceId) }
    }

    fun dismissError() { _uiState.update { it.copy(error = null) } }
}
