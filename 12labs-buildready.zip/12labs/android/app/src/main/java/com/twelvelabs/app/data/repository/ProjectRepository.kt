
package com.twelvelabs.app.data.repository

import com.twelvelabs.app.data.local.dao.ProjectDao
import com.twelvelabs.app.data.local.entities.ProjectEntity
import com.twelvelabs.app.data.remote.ApiService
import com.twelvelabs.app.data.remote.models.*
import com.twelvelabs.app.domain.model.Project
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ProjectRepository @Inject constructor(
    private val api: ApiService,
    private val dao: ProjectDao,
) {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US)

    fun observeProjects(): Flow<List<Project>> = dao.observeAll().map { list ->
        list.map { it.toDomain() }
    }

    suspend fun syncProjects(): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val resp = api.getProjects()
            if (resp.isSuccessful) {
                val entities = resp.body()!!.map { it.toEntity() }
                dao.upsertAll(entities)
            } else error("Sync failed: ${resp.code()}")
        }
    }

    suspend fun createProject(name: String = "Untitled Project"): Result<Project> = withContext(Dispatchers.IO) {
        runCatching {
            val resp = api.createProject(CreateProjectRequest(name = name))
            if (resp.isSuccessful) {
                val entity = resp.body()!!.toEntity()
                dao.upsert(entity)
                entity.toDomain()
            } else error("Create failed: ${resp.code()}")
        }
    }

    suspend fun updateProject(id: String, name: String? = null, script: String? = null, voiceId: String? = null, speed: Float? = null): Result<Project> = withContext(Dispatchers.IO) {
        runCatching {
            val resp = api.updateProject(id, UpdateProjectRequest(name, script, voiceId, speed))
            if (resp.isSuccessful) {
                val entity = resp.body()!!.toEntity()
                dao.upsert(entity)
                entity.toDomain()
            } else error("Update failed: ${resp.code()}")
        }
    }

    suspend fun deleteProject(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            api.deleteProject(id)
            dao.deleteById(id)
        }
    }

    suspend fun duplicateProject(id: String): Result<Project> = withContext(Dispatchers.IO) {
        runCatching {
            val resp = api.duplicateProject(id)
            if (resp.isSuccessful) {
                val entity = resp.body()!!.toEntity()
                dao.upsert(entity)
                entity.toDomain()
            } else error("Duplicate failed: ${resp.code()}")
        }
    }

    private fun ProjectDto.toEntity() = ProjectEntity(
        id, name, script, voiceId, speed, audioFormat, status, audioUrl,
        audioDurationSeconds, charsUsed,
        runCatching { createdAt?.let { dateFormat.parse(it.take(19)) } }.getOrNull(),
        runCatching { updatedAt?.let { dateFormat.parse(it.take(19)) } }.getOrNull(),
    )

    private fun ProjectEntity.toDomain() = Project(
        id, name, script, voiceId, speed, audioFormat, status,
        audioUrl, audioDurationSeconds, charsUsed, createdAt, updatedAt
    )
}
