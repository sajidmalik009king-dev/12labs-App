
package com.twelvelabs.app.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.twelvelabs.app.ui.theme.*

@Composable
fun SettingsScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Black900)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(top = 16.dp, bottom = 100.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineLarge, color = TextPrimary, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))

        SettingsSection("Generation") {
            SettingsItem(Icons.Default.Speed, "Default Speed", "1.0x")
            SettingsItem(Icons.Default.AudioFile, "Default Format", "MP3")
            SettingsItem(Icons.Default.RecordVoiceOver, "Default Voice", "Not set")
        }

        Spacer(Modifier.height(16.dp))

        SettingsSection("Account") {
            SettingsItem(Icons.Default.Person, "Account", null)
            SettingsItem(Icons.Default.Star, "Subscription", "Free")
            SettingsItem(Icons.Default.BarChart, "Usage", null)
        }

        Spacer(Modifier.height(16.dp))

        SettingsSection("Storage") {
            SettingsItem(Icons.Default.Folder, "Download Location", "Downloads")
        }

        Spacer(Modifier.height(16.dp))

        SettingsSection("Legal") {
            SettingsItem(Icons.Default.PrivacyTip, "Privacy Policy", null)
            SettingsItem(Icons.Default.Article, "Terms of Service", null)
        }

        Spacer(Modifier.height(16.dp))

        SettingsSection("Danger Zone") {
            SettingsDangerItem(Icons.Default.DeleteForever, "Delete Account")
        }
    }
}

@Composable
fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(title.uppercase(), style = MaterialTheme.typography.labelSmall, color = TextMuted, letterSpacing = androidx.compose.ui.unit.TextUnit.Unspecified)
    Spacer(Modifier.height(8.dp))
    Surface(
        color = Black700,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(content = content)
    }
}

@Composable
fun SettingsItem(icon: ImageVector, label: String, value: String?) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(14.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, color = TextPrimary, modifier = Modifier.weight(1f))
        if (value != null) {
            Text(value, style = MaterialTheme.typography.bodySmall, color = TextMuted)
        }
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextMuted, modifier = Modifier.size(16.dp))
    }
}

@Composable
fun SettingsDangerItem(icon: ImageVector, label: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = ErrorColor, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(14.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, color = ErrorColor, modifier = Modifier.weight(1f))
    }
}
