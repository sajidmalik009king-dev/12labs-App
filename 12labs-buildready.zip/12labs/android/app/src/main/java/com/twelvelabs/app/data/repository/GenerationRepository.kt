
package com.twelvelabs.app.data.repository

import com.twelvelabs.app.data.remote.ApiService
import com.twelvelabs.app.data.remote.models.GenerateRequest
import com.twelvelabs.app.domain.model.GenerationJob
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GenerationRepository @Inject constructor(private val api: ApiService) {

    suspend fun startGeneration(
        projectId: String,
        voiceId: String,
        script: String,
        speed: Float = 1.0f,
        audioFormat: String = "mp3",
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val resp = api.startGeneration(
                GenerateRequest(projectId, voiceId, script, speed, audioFormat)
            )
            if (resp.isSuccessful) resp.body()!!.jobId
            else {
                val code = resp.code()
                val msg = when (code) {
                    402 -> "Character limit exceeded. Upgrade for more."
                    403 -> "This voice or format requires a higher plan."
                    429 -> "Too many requests. Please wait and try again."
                    else -> "Voice generation failed. Please try again."
                }
                error(msg)
            }
        }
    }

    fun pollJobStatus(jobId: String): Flow<GenerationJob> = flow {
        var done = false
        var retries = 0
        while (!done && retries < 120) {
            val resp = runCatching { api.getJobStatus(jobId) }.getOrNull()
            if (resp?.isSuccessful == true) {
                val body = resp.body()!!
                emit(GenerationJob(body.jobId, body.status, body.progress, body.audioUrl, body.error))
                if (body.status == "done" || body.status == "failed") done = true
            }
            if (!done) delay(2000)
            retries++
        }
    }
}
