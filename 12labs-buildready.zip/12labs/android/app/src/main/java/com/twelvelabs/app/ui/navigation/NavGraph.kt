
package com.twelvelabs.app.ui.navigation

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.twelvelabs.app.ui.home.HomeScreen
import com.twelvelabs.app.ui.voices.VoicesScreen
import com.twelvelabs.app.ui.projects.ProjectsScreen
import com.twelvelabs.app.ui.settings.SettingsScreen
import com.twelvelabs.app.ui.theme.*

sealed class Screen(val route: String, val label: String) {
    object Home : Screen("home", "Home")
    object Voices : Screen("voices", "Voices")
    object Projects : Screen("projects", "Projects")
    object Settings : Screen("settings", "Settings")
}

@Composable
fun TwelveLabsNavGraph() {
    val navController = rememberNavController()

    val items = listOf(
        Triple(Screen.Home, Icons.Default.Home, "Home"),
        Triple(Screen.Voices, Icons.Default.RecordVoiceOver, "Voices"),
        Triple(Screen.Projects, Icons.Default.FolderOpen, "Projects"),
        Triple(Screen.Settings, Icons.Default.Settings, "Settings"),
    )

    Scaffold(
        containerColor = Black900,
        bottomBar = {
            NavigationBar(
                containerColor = Black800,
                tonalElevation = 0.dp,
            ) {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination
                items.forEach { (screen, icon, label) ->
                    NavigationBarItem(
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                        selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Accent,
                            selectedTextColor = Accent,
                            indicatorColor = AccentGlow.copy(alpha = 0.2f),
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted,
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) { HomeScreen() }
            composable(Screen.Voices.route) { VoicesScreen() }
            composable(Screen.Projects.route) { ProjectsScreen() }
            composable(Screen.Settings.route) { SettingsScreen() }
        }
    }
}
