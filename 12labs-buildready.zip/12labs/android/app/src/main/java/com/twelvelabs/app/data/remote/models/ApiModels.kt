
package com.twelvelabs.app.data.remote.models

import com.google.gson.annotations.SerializedName

data class VoiceDto(
    val id: String,
    @SerializedName("display_name") val displayName: String,
    val description: String?,
    val accent: String?,
    @SerializedName("tier_required") val tierRequired: String,
    @SerializedName("preview_url") val previewUrl: String?,
)

data class ProjectDto(
    val id: String,
    val name: String,
    val script: String,
    @SerializedName("voice_id") val voiceId: String?,
    val speed: Float,
    @SerializedName("audio_format") val audioFormat: String,
    val status: String,
    @SerializedName("audio_url") val audioUrl: String?,
    @SerializedName("audio_duration_seconds") val audioDurationSeconds: Float?,
    @SerializedName("chars_used") val charsUsed: Int?,
    @SerializedName("created_at") val createdAt: String?,
    @SerializedName("updated_at") val updatedAt: String?,
)

data class CreateProjectRequest(
    val name: String = "Untitled Project",
    val script: String = "",
    @SerializedName("voice_id") val voiceId: String? = null,
    val speed: Float = 1.0f,
    @SerializedName("audio_format") val audioFormat: String = "mp3",
)

data class UpdateProjectRequest(
    val name: String? = null,
    val script: String? = null,
    @SerializedName("voice_id") val voiceId: String? = null,
    val speed: Float? = null,
)

data class GenerateRequest(
    @SerializedName("project_id") val projectId: String,
    @SerializedName("voice_id") val voiceId: String,
    val script: String,
    val speed: Float = 1.0f,
    @SerializedName("audio_format") val audioFormat: String = "mp3",
    @SerializedName("voice_settings_override") val voiceSettingsOverride: Map<String, Any>? = null,
)

data class GenerateResponse(
    @SerializedName("job_id") val jobId: String,
    val status: String,
    val message: String,
)

data class JobStatusResponse(
    @SerializedName("job_id") val jobId: String,
    val status: String,
    val progress: Float,
    @SerializedName("audio_url") val audioUrl: String?,
    val error: String?,
)

data class UsageDto(
    @SerializedName("chars_used") val charsUsed: Int,
    @SerializedName("chars_limit") val charsLimit: Int,
    @SerializedName("subscription_tier") val subscriptionTier: String,
    @SerializedName("formats_available") val formatsAvailable: List<String>,
)

data class PronunciationRuleDto(
    val id: String,
    val word: String,
    val pronunciation: String,
)

data class CreatePronunciationRequest(val word: String, val pronunciation: String)

data class MeResponse(
    val id: String,
    val email: String?,
    @SerializedName("display_name") val displayName: String?,
    @SerializedName("subscription_tier") val subscriptionTier: String,
)
