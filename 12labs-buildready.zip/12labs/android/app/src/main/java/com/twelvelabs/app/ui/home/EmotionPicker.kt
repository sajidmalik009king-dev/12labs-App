
package com.twelvelabs.app.ui.home

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twelvelabs.app.domain.model.ALL_EMOTION_TAGS
import com.twelvelabs.app.domain.model.EmotionCategory
import com.twelvelabs.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun EmotionPickerSheet(
    onTagSelected: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Black800,
        dragHandle = { BottomSheetDefaults.DragHandle(color = TextMuted) },
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
        ) {
            Text(
                "Emotion Tags",
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimary,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            Text(
                "Tap a tag to insert at cursor position",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted,
                modifier = Modifier.padding(bottom = 20.dp)
            )

            EmotionCategory.entries.forEach { category ->
                val tags = ALL_EMOTION_TAGS.filter { it.category == category }
                Text(
                    category.label,
                    style = MaterialTheme.typography.labelMedium,
                    color = Accent,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(top = 12.dp, bottom = 8.dp)
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    tags.forEach { emotionTag ->
                        AssistChip(
                            onClick = { onTagSelected("[${emotionTag.tag}]") },
                            label = { Text("[${emotionTag.tag}]", style = MaterialTheme.typography.labelMedium) },
                            shape = RoundedCornerShape(8.dp),
                            colors = AssistChipDefaults.assistChipColors(
                                containerColor = Black600,
                                labelColor = TextSecondary,
                            ),
                            border = AssistChipDefaults.assistChipBorder(enabled = true, borderColor = DividerColor)
                        )
                    }
                }
            }
        }
    }
}
