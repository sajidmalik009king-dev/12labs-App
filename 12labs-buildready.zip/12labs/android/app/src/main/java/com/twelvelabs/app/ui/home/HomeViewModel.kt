
package com.twelvelabs.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.twelvelabs.app.data.repository.GenerationRepository
import com.twelvelabs.app.data.repository.ProjectRepository
import com.twelvelabs.app.data.repository.VoiceRepository
import com.twelvelabs.app.domain.model.Voice
import com.twelvelabs.app.domain.model.GenerationJob
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val script: String = "",
    val selectedVoice: Voice? = null,
    val speed: Float = 1.0f,
    val isGenerating: Boolean = false,
    val generationProgress: Float = 0f,
    val generationJobId: String? = null,
    val currentProjectId: String? = null,
    val generatedAudioUrl: String? = null,
    val error: String? = null,
    val showEmotionPicker: Boolean = false,
    val showVoicePicker: Boolean = false,
    val showPlayer: Boolean = false,
)

val String.wordCount get() = trim().split(Regex("\\s+")).count { it.isNotBlank() }
val String.estimatedDurationSeconds get() = (wordCount / 2.5f).toInt() // ~150 wpm average
fun Int.toTimeString(): String = "%d:%02d".format(this / 60, this % 60)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val projectRepo: ProjectRepository,
    private val voiceRepo: VoiceRepository,
    private val generationRepo: GenerationRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    private val _currentProjectId = MutableStateFlow<String?>(null)

    fun onScriptChange(text: String) {
        _uiState.update { it.copy(script = text, error = null) }
        autosave(text)
    }

    fun onVoiceSelected(voice: Voice) {
        _uiState.update { it.copy(selectedVoice = voice, showVoicePicker = false) }
    }

    fun onSpeedChange(speed: Float) {
        _uiState.update { it.copy(speed = speed) }
    }

    fun onInsertEmotionTag(tag: String) {
        // Tag insertion handled in UI at cursor position
        _uiState.update { it.copy(showEmotionPicker = false) }
    }

    fun toggleEmotionPicker() {
        _uiState.update { it.copy(showEmotionPicker = !it.showEmotionPicker) }
    }

    fun toggleVoicePicker() {
        _uiState.update { it.copy(showVoicePicker = !it.showVoicePicker) }
    }

    fun dismissError() {
        _uiState.update { it.copy(error = null) }
    }

    fun dismissPlayer() {
        _uiState.update { it.copy(showPlayer = false) }
    }

    fun generateVoice() {
        val state = _uiState.value
        val voice = state.selectedVoice
        val script = state.script.trim()

        if (voice == null) {
            _uiState.update { it.copy(error = "Please select a voice first.") }
            return
        }
        if (script.isBlank()) {
            _uiState.update { it.copy(error = "Please enter a script first.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isGenerating = true, generationProgress = 0f, error = null) }

            // Create project if needed
            val projectId = _currentProjectId.value ?: run {
                projectRepo.createProject().getOrNull()?.id.also {
                    _currentProjectId.value = it
                }
            } ?: run {
                _uiState.update { it.copy(isGenerating = false, error = "Failed to create project.") }
                return@launch
            }

            // Update project with latest script + voice
            projectRepo.updateProject(projectId, script = script, voiceId = voice.id, speed = state.speed)

            // Start generation
            val jobResult = generationRepo.startGeneration(
                projectId = projectId,
                voiceId = voice.id,
                script = script,
                speed = state.speed,
            )

            if (jobResult.isFailure) {
                _uiState.update { it.copy(isGenerating = false, error = jobResult.exceptionOrNull()?.message ?: "Generation failed.") }
                return@launch
            }

            val jobId = jobResult.getOrThrow()
            _uiState.update { it.copy(generationJobId = jobId) }

            // Poll status
            generationRepo.pollJobStatus(jobId).collect { job ->
                _uiState.update { it.copy(generationProgress = job.progress) }
                when (job.status) {
                    "done" -> {
                        _uiState.update {
                            it.copy(
                                isGenerating = false,
                                generatedAudioUrl = job.audioUrl,
                                showPlayer = job.audioUrl != null,
                                currentProjectId = projectId,
                            )
                        }
                    }
                    "failed" -> {
                        _uiState.update { it.copy(isGenerating = false, error = job.error ?: "Voice generation failed. Please try again.") }
                    }
                }
            }
        }
    }

    private var autosaveJob: kotlinx.coroutines.Job? = null
    private fun autosave(script: String) {
        autosaveJob?.cancel()
        autosaveJob = viewModelScope.launch {
            delay(1500)
            val projectId = _currentProjectId.value ?: return@launch
            projectRepo.updateProject(projectId, script = script)
        }
    }
}
