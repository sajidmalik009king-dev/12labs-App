
package com.twelvelabs.app.data.repository

import com.twelvelabs.app.data.remote.ApiService
import com.twelvelabs.app.domain.model.Voice
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class VoiceRepository @Inject constructor(private val api: ApiService) {
    suspend fun getVoices(): Result<List<Voice>> = withContext(Dispatchers.IO) {
        runCatching {
            val resp = api.getVoices()
            if (resp.isSuccessful) {
                resp.body()!!.map {
                    Voice(it.id, it.displayName, it.description, it.accent, it.tierRequired, it.previewUrl)
                }
            } else error("Failed to load voices: ${resp.code()}")
        }
    }
}
