
package com.twelvelabs.app.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// 12Labs Brand Colors
val Black900 = Color(0xFF080810)
val Black800 = Color(0xFF0F0F1A)
val Black700 = Color(0xFF16162A)
val Black600 = Color(0xFF1E1E30)
val Black500 = Color(0xFF252540)
val Accent = Color(0xFF7C3AED)       // Premium purple
val AccentLight = Color(0xFF9D5FF0)
val AccentGlow = Color(0xFF5B21B6)
val TextPrimary = Color(0xFFEEEEFF)
val TextSecondary = Color(0xFF9090B0)
val TextMuted = Color(0xFF5A5A7A)
val Surface100 = Color(0xFF1A1A2E)
val Surface200 = Color(0xFF20203A)
val DividerColor = Color(0xFF252545)
val ErrorColor = Color(0xFFEF4444)
val SuccessColor = Color(0xFF10B981)

private val DarkColorScheme = darkColorScheme(
    primary = Accent,
    onPrimary = Color.White,
    primaryContainer = AccentGlow,
    onPrimaryContainer = TextPrimary,
    secondary = AccentLight,
    onSecondary = Color.White,
    background = Black900,
    onBackground = TextPrimary,
    surface = Black800,
    onSurface = TextPrimary,
    surfaceVariant = Black700,
    onSurfaceVariant = TextSecondary,
    outline = DividerColor,
    error = ErrorColor,
    onError = Color.White,
)

@Composable
fun TwelveLabsTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = TwelveLabsTypography,
        content = content
    )
}
