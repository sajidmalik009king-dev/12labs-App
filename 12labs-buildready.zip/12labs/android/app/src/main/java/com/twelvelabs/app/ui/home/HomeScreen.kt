
package com.twelvelabs.app.ui.home

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.selection.LocalTextSelectionColors
import androidx.compose.foundation.text.selection.TextSelectionColors
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.twelvelabs.app.ui.components.*
import com.twelvelabs.app.ui.player.AudioPlayerSheet
import com.twelvelabs.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(viewModel: HomeViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var textFieldValue by remember { mutableStateOf(TextFieldValue("")) }
    val keyboardController = LocalSoftwareKeyboardController.current

    // Sync external script changes (e.g. from autosave restore)
    LaunchedEffect(state.script) {
        if (state.script != textFieldValue.text) {
            textFieldValue = textFieldValue.copy(text = state.script)
        }
    }

    if (state.showEmotionPicker) {
        EmotionPickerSheet(
            onTagSelected = { tag ->
                // Insert at cursor position
                val cursor = textFieldValue.selection.start
                val newText = textFieldValue.text.take(cursor) + tag + textFieldValue.text.drop(cursor)
                val newCursor = cursor + tag.length
                textFieldValue = textFieldValue.copy(
                    text = newText,
                    selection = TextRange(newCursor)
                )
                viewModel.onScriptChange(newText)
                viewModel.toggleEmotionPicker()
            },
            onDismiss = { viewModel.toggleEmotionPicker() }
        )
    }

    if (state.showPlayer && state.generatedAudioUrl != null) {
        AudioPlayerSheet(
            audioUrl = state.generatedAudioUrl!!,
            projectName = "Your Voiceover",
            onDismiss = { viewModel.dismissPlayer() },
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Black900)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(top = 16.dp, bottom = 100.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                Text(
                    "12Labs",
                    style = MaterialTheme.typography.headlineLarge,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    "Create your voiceover",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                )
            }
        }

        Spacer(Modifier.height(24.dp))

        // Error
        state.error?.let { error ->
            ErrorBanner(message = error, onDismiss = { viewModel.dismissError() })
            Spacer(Modifier.height(16.dp))
        }

        // Script Editor Card
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Script", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                IconButton(
                    onClick = {
                        textFieldValue = TextFieldValue("")
                        viewModel.onScriptChange("")
                    },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextMuted, modifier = Modifier.size(18.dp))
                }
            }

            Spacer(Modifier.height(8.dp))

            CompositionLocalProvider(
                LocalTextSelectionColors provides TextSelectionColors(
                    handleColor = Accent,
                    backgroundColor = Accent.copy(alpha = 0.3f)
                )
            ) {
                BasicTextField(
                    value = textFieldValue,
                    onValueChange = { newValue ->
                        textFieldValue = newValue
                        viewModel.onScriptChange(newValue.text)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 200.dp, max = 400.dp),
                    textStyle = MaterialTheme.typography.bodyLarge.copy(
                        color = TextPrimary,
                        lineHeight = 26.sp,
                    ),
                    cursorBrush = SolidColor(Accent),
                    decorationBox = { innerTextField ->
                        Box(
                            modifier = Modifier
                                .background(Black800, RoundedCornerShape(10.dp))
                                .padding(14.dp)
                        ) {
                            if (textFieldValue.text.isEmpty()) {
                                Text(
                                    "Paste or type your script here...\n\nYou can add emotion tags like [sighs] or [pause]",
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        color = TextMuted,
                                        lineHeight = 26.sp,
                                    )
                                )
                            }
                            innerTextField()
                        }
                    }
                )
            }

            Spacer(Modifier.height(12.dp))

            // Stats row
            val text = state.script
            val chars = text.length
            val words = text.wordCount
            val durSec = text.estimatedDurationSeconds

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text("Characters: ${chars.toString().padStart(1)}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                Text("Words: $words", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                Text("≈ ${durSec.toTimeString()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }

            Spacer(Modifier.height(12.dp))

            // Emotion button
            OutlinedButton(
                onClick = { viewModel.toggleEmotionPicker() },
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentLight),
                border = BorderStroke(1.dp, Accent.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Icon(Icons.Default.EmojiEmotions, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Add Emotion Tags", style = MaterialTheme.typography.labelLarge)
            }
        }

        Spacer(Modifier.height(16.dp))

        // Voice Selector Card
        AppCard(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.toggleVoicePicker() }
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Voice", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Spacer(Modifier.height(4.dp))
                    if (state.selectedVoice != null) {
                        Text(state.selectedVoice!!.displayName, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                        state.selectedVoice!!.description?.let {
                            Text(it, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                    } else {
                        Text("Select a voice", style = MaterialTheme.typography.titleMedium, color = TextMuted)
                    }
                }
                Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextMuted)
            }
        }

        // Voice picker bottom sheet
        if (state.showVoicePicker) {
            VoicePickerSheet(
                onVoiceSelected = { viewModel.onVoiceSelected(it) },
                onDismiss = { viewModel.toggleVoicePicker() },
                currentVoiceId = state.selectedVoice?.id,
            )
        }

        Spacer(Modifier.height(16.dp))

        // Speed control
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Text("Speed", style = MaterialTheme.typography.labelSmall, color = TextMuted)
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { speed ->
                    val selected = state.speed == speed
                    FilterChip(
                        selected = selected,
                        onClick = { viewModel.onSpeedChange(speed) },
                        label = { Text("${speed}x".removeSuffix(".0x") + "x", style = MaterialTheme.typography.labelSmall) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Accent,
                            selectedLabelColor = Color.White,
                            containerColor = Black600,
                            labelColor = TextSecondary,
                        ),
                        shape = RoundedCornerShape(8.dp),
                        border = FilterChipDefaults.filterChipBorder(enabled = true, selected = selected, borderColor = DividerColor, selectedBorderColor = Accent)
                    )
                }
            }
        }

        Spacer(Modifier.height(24.dp))

        // Generation progress
        if (state.isGenerating) {
            AppCard(modifier = Modifier.fillMaxWidth()) {
                Text("Generating voiceover...", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { state.generationProgress },
                    modifier = Modifier.fillMaxWidth().height(4.dp),
                    color = Accent,
                    trackColor = Black600,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "${(state.generationProgress * 100).toInt()}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = Accent
                )
            }
            Spacer(Modifier.height(16.dp))
        }

        // Generate button
        GradientButton(
            text = if (state.isGenerating) "Generating..." else "GENERATE VOICE",
            onClick = { viewModel.generateVoice() },
            modifier = Modifier.fillMaxWidth(),
            enabled = !state.isGenerating && state.script.isNotBlank() && state.selectedVoice != null,
            isLoading = state.isGenerating,
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoicePickerSheet(
    onVoiceSelected: (com.twelvelabs.app.domain.model.Voice) -> Unit,
    onDismiss: () -> Unit,
    currentVoiceId: String?,
) {
    val viewModel: com.twelvelabs.app.ui.voices.VoicesViewModel = hiltViewModel()
    val voicesState by viewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) { viewModel.loadVoices() }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Black800,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
        ) {
            Text("Select Voice", style = MaterialTheme.typography.titleLarge, color = TextPrimary, modifier = Modifier.padding(bottom = 16.dp))
            voicesState.voices.forEach { voice ->
                val isSelected = voice.id == currentVoiceId
                Surface(
                    onClick = { onVoiceSelected(voice) },
                    color = if (isSelected) Accent.copy(alpha = 0.15f) else Black700,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(voice.displayName, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                            voice.description?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextSecondary) }
                        }
                        if (isSelected) Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Accent)
                    }
                }
            }
        }
    }
}
