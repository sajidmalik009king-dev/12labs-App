
package com.twelvelabs.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.twelvelabs.app.ui.navigation.TwelveLabsNavGraph
import com.twelvelabs.app.ui.theme.TwelveLabsTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TwelveLabsTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    TwelveLabsNavGraph()
                }
            }
        }
    }
}
