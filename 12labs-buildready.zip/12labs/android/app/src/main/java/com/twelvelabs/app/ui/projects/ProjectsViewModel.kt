
package com.twelvelabs.app.ui.projects

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.twelvelabs.app.data.repository.ProjectRepository
import com.twelvelabs.app.domain.model.Project
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ProjectsUiState(
    val projects: List<Project> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val playingProjectUrl: String? = null,
    val showPlayerForProject: Project? = null,
)

@HiltViewModel
class ProjectsViewModel @Inject constructor(
    private val projectRepo: ProjectRepository,
) : ViewModel() {
    private val _uiState = MutableStateFlow(ProjectsUiState())
    val uiState: StateFlow<ProjectsUiState> = _uiState.asStateFlow()

    init {
        // Observe local cache
        viewModelScope.launch {
            projectRepo.observeProjects().collect { projects ->
                _uiState.update { it.copy(projects = projects) }
            }
        }
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            projectRepo.syncProjects()
                .onFailure { _uiState.update { it.copy(error = "Failed to load projects.") } }
            _uiState.update { it.copy(isLoading = false) }
        }
    }

    fun deleteProject(projectId: String) {
        viewModelScope.launch { projectRepo.deleteProject(projectId) }
    }

    fun duplicateProject(projectId: String) {
        viewModelScope.launch { projectRepo.duplicateProject(projectId) }
    }

    fun playProject(project: Project) {
        _uiState.update { it.copy(showPlayerForProject = project) }
    }

    fun dismissPlayer() {
        _uiState.update { it.copy(showPlayerForProject = null) }
    }

    fun dismissError() { _uiState.update { it.copy(error = null) } }
}
