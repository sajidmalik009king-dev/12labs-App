
package com.twelvelabs.app.ui.voices

import android.net.Uri
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import com.twelvelabs.app.domain.model.Voice
import com.twelvelabs.app.ui.components.*
import com.twelvelabs.app.ui.theme.*

@Composable
fun VoicesScreen(viewModel: VoicesViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // ExoPlayer for preview audio
    val exoPlayer = remember {
        ExoPlayer.Builder(context).build()
    }
    DisposableEffect(Unit) {
        onDispose { exoPlayer.release() }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Black900)
    ) {
        // Top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column {
                Text("Voices", style = MaterialTheme.typography.headlineLarge, color = TextPrimary, fontWeight = FontWeight.Bold)
                Text("${state.voices.size} voices available", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
            if (state.isLoading) CircularProgressIndicator(modifier = Modifier.size(24.dp), color = Accent, strokeWidth = 2.dp)
        }

        state.error?.let { ErrorBanner(it, onDismiss = viewModel::dismissError) }

        if (state.isLoading && state.voices.isEmpty()) {
            LoadingIndicator("Loading voices...")
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(state.voices, key = { it.id }) { voice ->
                    VoiceCard(
                        voice = voice,
                        isSelected = state.selectedVoiceId == voice.id,
                        isPlaying = state.playingVoiceId == voice.id,
                        onSelect = { viewModel.selectVoice(voice.id) },
                        onPreview = {
                            if (state.playingVoiceId == voice.id) {
                                exoPlayer.stop()
                                viewModel.setPlayingVoice(null)
                            } else {
                                voice.previewUrl?.let { url ->
                                    exoPlayer.setMediaItem(MediaItem.fromUri(url))
                                    exoPlayer.prepare()
                                    exoPlayer.play()
                                    viewModel.setPlayingVoice(voice.id)
                                }
                            }
                        }
                    )
                }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }
    }
}

@Composable
fun VoiceCard(
    voice: Voice,
    isSelected: Boolean,
    isPlaying: Boolean,
    onSelect: () -> Unit,
    onPreview: () -> Unit,
) {
    Surface(
        color = if (isSelected) Accent.copy(alpha = 0.12f) else Black700,
        shape = RoundedCornerShape(14.dp),
        border = if (isSelected) BorderStroke(1.5.dp, Accent) else BorderStroke(1.dp, DividerColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(voice.displayName, style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                        if (voice.tierRequired != "free") {
                            Surface(
                                color = Accent.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    voice.tierRequired.uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AccentLight,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    voice.description?.let {
                        Spacer(Modifier.height(2.dp))
                        Text(it, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                    voice.accent?.let {
                        Text(it, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                // Preview button
                OutlinedButton(
                    onClick = onPreview,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = if (isPlaying) Accent else TextSecondary
                    ),
                    border = BorderStroke(1.dp, if (isPlaying) Accent else DividerColor),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(if (isPlaying) "Stop" else "Preview", style = MaterialTheme.typography.labelMedium)
                }

                // Select button
                Button(
                    onClick = onSelect,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) Accent else Black500,
                        contentColor = Color.White,
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    if (isSelected) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                    }
                    Text(if (isSelected) "Selected" else "Select", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}
