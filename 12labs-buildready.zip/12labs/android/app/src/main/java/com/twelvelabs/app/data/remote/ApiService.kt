
package com.twelvelabs.app.data.remote

import com.twelvelabs.app.data.remote.models.*
import retrofit2.Response
import retrofit2.http.*

interface ApiService {
    // Auth
    @GET("auth/me")
    suspend fun getMe(): Response<MeResponse>

    // Voices
    @GET("voices")
    suspend fun getVoices(): Response<List<VoiceDto>>

    // Projects
    @GET("projects")
    suspend fun getProjects(
        @Query("limit") limit: Int = 50,
        @Query("offset") offset: Int = 0,
    ): Response<List<ProjectDto>>

    @POST("projects")
    suspend fun createProject(@Body body: CreateProjectRequest): Response<ProjectDto>

    @GET("projects/{id}")
    suspend fun getProject(@Path("id") id: String): Response<ProjectDto>

    @PUT("projects/{id}")
    suspend fun updateProject(@Path("id") id: String, @Body body: UpdateProjectRequest): Response<ProjectDto>

    @DELETE("projects/{id}")
    suspend fun deleteProject(@Path("id") id: String): Response<Unit>

    @POST("projects/{id}/duplicate")
    suspend fun duplicateProject(@Path("id") id: String): Response<ProjectDto>

    // Generation
    @POST("generate")
    suspend fun startGeneration(@Body body: GenerateRequest): Response<GenerateResponse>

    @GET("generate/{jobId}/status")
    suspend fun getJobStatus(@Path("jobId") jobId: String): Response<JobStatusResponse>

    // Usage
    @GET("usage/me")
    suspend fun getUsage(): Response<UsageDto>

    // Pronunciation
    @GET("pronunciation")
    suspend fun getPronunciationRules(): Response<List<PronunciationRuleDto>>

    @POST("pronunciation")
    suspend fun createPronunciationRule(@Body body: CreatePronunciationRequest): Response<PronunciationRuleDto>

    @DELETE("pronunciation/{id}")
    suspend fun deletePronunciationRule(@Path("id") id: String): Response<Unit>
}
