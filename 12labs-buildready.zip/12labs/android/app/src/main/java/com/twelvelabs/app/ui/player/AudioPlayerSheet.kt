
package com.twelvelabs.app.ui.player

import android.content.Context
import android.content.Intent
import android.os.Environment
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.twelvelabs.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AudioPlayerSheet(
    audioUrl: String,
    projectName: String,
    onDismiss: () -> Unit,
    onDownload: (() -> Unit)? = null,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().also { player ->
            player.setMediaItem(MediaItem.fromUri(audioUrl))
            player.prepare()
        }
    }
    DisposableEffect(Unit) {
        onDispose { exoPlayer.release() }
    }

    var isPlaying by remember { mutableStateOf(false) }
    var currentPositionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var speed by remember { mutableFloatStateOf(1f) }

    // Update position tick
    LaunchedEffect(exoPlayer) {
        while (isActive) {
            currentPositionMs = exoPlayer.currentPosition
            durationMs = exoPlayer.duration.coerceAtLeast(0L)
            isPlaying = exoPlayer.isPlaying
            delay(250)
        }
    }

    DisposableEffect(speed) {
        exoPlayer.setPlaybackSpeed(speed)
        onDispose { }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Black800,
        dragHandle = { BottomSheetDefaults.DragHandle(color = TextMuted) },
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Your Voiceover", style = MaterialTheme.typography.titleLarge, color = TextPrimary, fontWeight = FontWeight.Bold)
            Text(projectName, style = MaterialTheme.typography.bodySmall, color = TextSecondary)

            Spacer(Modifier.height(24.dp))

            // Timeline
            val progress = if (durationMs > 0) currentPositionMs.toFloat() / durationMs else 0f
            Slider(
                value = progress,
                onValueChange = { p -> exoPlayer.seekTo((p * durationMs).toLong()) },
                modifier = Modifier.fillMaxWidth(),
                colors = SliderDefaults.colors(
                    thumbColor = Accent,
                    activeTrackColor = Accent,
                    inactiveTrackColor = Black500,
                )
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(formatMs(currentPositionMs), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                Text(formatMs(durationMs), style = MaterialTheme.typography.labelSmall, color = TextMuted)
            }

            Spacer(Modifier.height(16.dp))

            // Main controls
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(onClick = { exoPlayer.seekTo(0); exoPlayer.play() }) {
                    Icon(Icons.Default.Replay, contentDescription = "Restart", tint = TextSecondary, modifier = Modifier.size(28.dp))
                }

                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(Accent),
                    contentAlignment = Alignment.Center
                ) {
                    IconButton(onClick = {
                        if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                    }) {
                        Icon(
                            if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = Color.White,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }

                IconButton(onClick = {
                    onDownload?.invoke() ?: downloadAudio(context, audioUrl, projectName)
                }) {
                    Icon(Icons.Default.Download, contentDescription = "Download", tint = TextSecondary, modifier = Modifier.size(28.dp))
                }
            }

            Spacer(Modifier.height(20.dp))

            // Playback speed
            Text("Speed", style = MaterialTheme.typography.labelSmall, color = TextMuted, modifier = Modifier.align(Alignment.Start))
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { s ->
                    val sel = speed == s
                    FilterChip(
                        selected = sel,
                        onClick = { speed = s },
                        label = { Text("${s}x".let { if (it == "1.0x") "1x" else it.replace(".0x", "x") }, style = MaterialTheme.typography.labelSmall) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Accent,
                            selectedLabelColor = Color.White,
                            containerColor = Black600,
                            labelColor = TextSecondary,
                        ),
                        shape = RoundedCornerShape(6.dp),
                        border = FilterChipDefaults.filterChipBorder(enabled = true, selected = sel, borderColor = DividerColor)
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // Share button
            OutlinedButton(
                onClick = { shareAudio(context, audioUrl, projectName) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary),
                border = BorderStroke(1.dp, DividerColor)
            ) {
                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Share Audio")
            }
        }
    }
}

private fun formatMs(ms: Long): String {
    val totalSeconds = ms / 1000
    return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}

private fun downloadAudio(context: Context, url: String, projectName: String) {
    val sanitized = projectName.replace("[^a-zA-Z0-9_]".toRegex(), "_")
    val fileName = "12Labs_${sanitized}.mp3"
    val request = android.app.DownloadManager.Request(android.net.Uri.parse(url))
        .setTitle(fileName)
        .setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
    val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as android.app.DownloadManager
    dm.enqueue(request)
}

private fun shareAudio(context: Context, url: String, projectName: String) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "audio/mpeg"
        putExtra(Intent.EXTRA_SUBJECT, "12Labs Voiceover: $projectName")
        putExtra(Intent.EXTRA_TEXT, url)
    }
    context.startActivity(Intent.createChooser(intent, "Share Voiceover"))
}
