import os

def w(path, content):
    full = f'/data/12labs/android/{path}'
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, 'w') as f:
        f.write(content)
    print(f'wrote {path}')

BASE = 'app/src/main/java/com/twelvelabs/app'

# ── Shared Components ─────────────────────────────────────────────────────
w(f'{BASE}/ui/components/Components.kt', '''
package com.twelvelabs.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.twelvelabs.app.ui.theme.*

@Composable
fun GradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    isLoading: Boolean = false,
) {
    val gradient = Brush.horizontalGradient(listOf(Accent, AccentLight))
    Button(
        onClick = onClick,
        modifier = modifier.height(52.dp),
        enabled = enabled && !isLoading,
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
        contentPadding = PaddingValues(0.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(if (enabled) gradient else Brush.horizontalGradient(listOf(Black600, Black600))),
            contentAlignment = Alignment.Center
        ) {
            if (isLoading) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                    Text(text, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                }
            } else {
                Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, letterSpacing = 0.5.sp)
            }
        }
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text.uppercase(),
        style = MaterialTheme.typography.labelSmall,
        color = TextMuted,
        letterSpacing = 1.5.sp,
        modifier = modifier.padding(bottom = 8.dp)
    )
}

@Composable
fun ErrorBanner(message: String, onDismiss: () -> Unit = {}) {
    Surface(
        color = ErrorColor.copy(alpha = 0.15f),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(message, color = ErrorColor, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
            TextButton(onClick = onDismiss) {
                Text("Dismiss", color = ErrorColor, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
fun LoadingIndicator(message: String = "Loading...") {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            CircularProgressIndicator(color = Accent)
            Text(message, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun AppCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    Surface(
        modifier = modifier,
        color = Black700,
        shape = RoundedCornerShape(14.dp),
        tonalElevation = 0.dp,
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}
''')

# ── Home ViewModel ─────────────────────────────────────────────────────────
w(f'{BASE}/ui/home/HomeViewModel.kt', '''
package com.twelvelabs.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.twelvelabs.app.data.repository.GenerationRepository
import com.twelvelabs.app.data.repository.ProjectRepository
import com.twelvelabs.app.data.repository.VoiceRepository
import com.twelvelabs.app.domain.model.Voice
import com.twelvelabs.app.domain.model.GenerationJob
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val script: String = "",
    val selectedVoice: Voice? = null,
    val speed: Float = 1.0f,
    val isGenerating: Boolean = false,
    val generationProgress: Float = 0f,
    val generationJobId: String? = null,
    val currentProjectId: String? = null,
    val generatedAudioUrl: String? = null,
    val error: String? = null,
    val showEmotionPicker: Boolean = false,
    val showVoicePicker: Boolean = false,
    val showPlayer: Boolean = false,
)

val String.wordCount get() = trim().split("\\s+".toRegex()).count { it.isNotBlank() }
val String.estimatedDurationSeconds get() = (wordCount / 2.5f).toInt() // ~150 wpm average
fun Int.toTimeString(): String = "%d:%02d".format(this / 60, this % 60)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val projectRepo: ProjectRepository,
    private val voiceRepo: VoiceRepository,
    private val generationRepo: GenerationRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    private val _currentProjectId = MutableStateFlow<String?>(null)

    fun onScriptChange(text: String) {
        _uiState.update { it.copy(script = text, error = null) }
        autosave(text)
    }

    fun onVoiceSelected(voice: Voice) {
        _uiState.update { it.copy(selectedVoice = voice, showVoicePicker = false) }
    }

    fun onSpeedChange(speed: Float) {
        _uiState.update { it.copy(speed = speed) }
    }

    fun onInsertEmotionTag(tag: String) {
        // Tag insertion handled in UI at cursor position
        _uiState.update { it.copy(showEmotionPicker = false) }
    }

    fun toggleEmotionPicker() {
        _uiState.update { it.copy(showEmotionPicker = !it.showEmotionPicker) }
    }

    fun toggleVoicePicker() {
        _uiState.update { it.copy(showVoicePicker = !it.showVoicePicker) }
    }

    fun dismissError() {
        _uiState.update { it.copy(error = null) }
    }

    fun dismissPlayer() {
        _uiState.update { it.copy(showPlayer = false) }
    }

    fun generateVoice() {
        val state = _uiState.value
        val voice = state.selectedVoice
        val script = state.script.trim()

        if (voice == null) {
            _uiState.update { it.copy(error = "Please select a voice first.") }
            return
        }
        if (script.isBlank()) {
            _uiState.update { it.copy(error = "Please enter a script first.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isGenerating = true, generationProgress = 0f, error = null) }

            // Create project if needed
            val projectId = _currentProjectId.value ?: run {
                projectRepo.createProject().getOrNull()?.id.also {
                    _currentProjectId.value = it
                }
            } ?: run {
                _uiState.update { it.copy(isGenerating = false, error = "Failed to create project.") }
                return@launch
            }

            // Update project with latest script + voice
            projectRepo.updateProject(projectId, script = script, voiceId = voice.id, speed = state.speed)

            // Start generation
            val jobResult = generationRepo.startGeneration(
                projectId = projectId,
                voiceId = voice.id,
                script = script,
                speed = state.speed,
            )

            if (jobResult.isFailure) {
                _uiState.update { it.copy(isGenerating = false, error = jobResult.exceptionOrNull()?.message ?: "Generation failed.") }
                return@launch
            }

            val jobId = jobResult.getOrThrow()
            _uiState.update { it.copy(generationJobId = jobId) }

            // Poll status
            generationRepo.pollJobStatus(jobId).collect { job ->
                _uiState.update { it.copy(generationProgress = job.progress) }
                when (job.status) {
                    "done" -> {
                        _uiState.update {
                            it.copy(
                                isGenerating = false,
                                generatedAudioUrl = job.audioUrl,
                                showPlayer = job.audioUrl != null,
                                currentProjectId = projectId,
                            )
                        }
                    }
                    "failed" -> {
                        _uiState.update { it.copy(isGenerating = false, error = job.error ?: "Voice generation failed. Please try again.") }
                    }
                }
            }
        }
    }

    private var autosaveJob: kotlinx.coroutines.Job? = null
    private fun autosave(script: String) {
        autosaveJob?.cancel()
        autosaveJob = viewModelScope.launch {
            delay(1500)
            val projectId = _currentProjectId.value ?: return@launch
            projectRepo.updateProject(projectId, script = script)
        }
    }
}
''')

# ── Emotion Picker ────────────────────────────────────────────────────────
w(f'{BASE}/ui/home/EmotionPicker.kt', '''
package com.twelvelabs.app.ui.home

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.accompanist.flowlayout.FlowRow
import com.twelvelabs.app.domain.model.ALL_EMOTION_TAGS
import com.twelvelabs.app.domain.model.EmotionCategory
import com.twelvelabs.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmotionPickerSheet(
    onTagSelected: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Black800,
        dragHandle = { BottomSheetDefaults.DragHandle(color = TextMuted) },
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
        ) {
            Text(
                "Emotion Tags",
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimary,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            Text(
                "Tap a tag to insert at cursor position",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted,
                modifier = Modifier.padding(bottom = 20.dp)
            )

            EmotionCategory.entries.forEach { category ->
                val tags = ALL_EMOTION_TAGS.filter { it.category == category }
                Text(
                    category.label,
                    style = MaterialTheme.typography.labelMedium,
                    color = Accent,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(top = 12.dp, bottom = 8.dp)
                )
                androidx.compose.foundation.layout.FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    tags.forEach { emotionTag ->
                        AssistChip(
                            onClick = { onTagSelected("[${emotionTag.tag}]") },
                            label = { Text("[${emotionTag.tag}]", style = MaterialTheme.typography.labelMedium) },
                            shape = RoundedCornerShape(8.dp),
                            colors = AssistChipDefaults.assistChipColors(
                                containerColor = Black600,
                                labelColor = TextSecondary,
                            ),
                            border = AssistChipDefaults.assistChipBorder(enabled = true, borderColor = DividerColor)
                        )
                    }
                }
            }
        }
    }
}
''')

# ── Home Screen ────────────────────────────────────────────────────────────
w(f'{BASE}/ui/home/HomeScreen.kt', '''
package com.twelvelabs.app.ui.home

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.LocalTextSelectionColors
import androidx.compose.foundation.text.selection.TextSelectionColors
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.twelvelabs.app.ui.components.*
import com.twelvelabs.app.ui.player.AudioPlayerSheet
import com.twelvelabs.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(viewModel: HomeViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var textFieldValue by remember { mutableStateOf(TextFieldValue("")) }
    val keyboardController = LocalSoftwareKeyboardController.current

    // Sync external script changes (e.g. from autosave restore)
    LaunchedEffect(state.script) {
        if (state.script != textFieldValue.text) {
            textFieldValue = textFieldValue.copy(text = state.script)
        }
    }

    if (state.showEmotionPicker) {
        EmotionPickerSheet(
            onTagSelected = { tag ->
                // Insert at cursor position
                val cursor = textFieldValue.selection.start
                val newText = textFieldValue.text.take(cursor) + tag + textFieldValue.text.drop(cursor)
                val newCursor = cursor + tag.length
                textFieldValue = textFieldValue.copy(
                    text = newText,
                    selection = TextRange(newCursor)
                )
                viewModel.onScriptChange(newText)
                viewModel.toggleEmotionPicker()
            },
            onDismiss = { viewModel.toggleEmotionPicker() }
        )
    }

    if (state.showPlayer && state.generatedAudioUrl != null) {
        AudioPlayerSheet(
            audioUrl = state.generatedAudioUrl!!,
            projectName = "Your Voiceover",
            onDismiss = { viewModel.dismissPlayer() },
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Black900)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(top = 16.dp, bottom = 100.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                Text(
                    "12Labs",
                    style = MaterialTheme.typography.headlineLarge,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    "Create your voiceover",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                )
            }
        }

        Spacer(Modifier.height(24.dp))

        // Error
        state.error?.let { error ->
            ErrorBanner(message = error, onDismiss = { viewModel.dismissError() })
            Spacer(Modifier.height(16.dp))
        }

        // Script Editor Card
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Script", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                IconButton(
                    onClick = {
                        textFieldValue = TextFieldValue("")
                        viewModel.onScriptChange("")
                    },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextMuted, modifier = Modifier.size(18.dp))
                }
            }

            Spacer(Modifier.height(8.dp))

            CompositionLocalProvider(
                LocalTextSelectionColors provides TextSelectionColors(
                    handleColor = Accent,
                    backgroundColor = Accent.copy(alpha = 0.3f)
                )
            ) {
                BasicTextField(
                    value = textFieldValue,
                    onValueChange = { newValue ->
                        textFieldValue = newValue
                        viewModel.onScriptChange(newValue.text)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 200.dp, max = 400.dp),
                    textStyle = MaterialTheme.typography.bodyLarge.copy(
                        color = TextPrimary,
                        lineHeight = 26.sp,
                    ),
                    cursorBrush = SolidColor(Accent),
                    decorationBox = { innerTextField ->
                        Box(
                            modifier = Modifier
                                .background(Black800, RoundedCornerShape(10.dp))
                                .padding(14.dp)
                        ) {
                            if (textFieldValue.text.isEmpty()) {
                                Text(
                                    "Paste or type your script here...\n\nYou can add emotion tags like [sighs] or [pause]",
                                    style = MaterialTheme.typography.bodyLarge.copy(
                                        color = TextMuted,
                                        lineHeight = 26.sp,
                                    )
                                )
                            }
                            innerTextField()
                        }
                    }
                )
            }

            Spacer(Modifier.height(12.dp))

            // Stats row
            val text = state.script
            val chars = text.length
            val words = text.wordCount
            val durSec = text.estimatedDurationSeconds

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text("Characters: ${chars.toString().padStart(1)}", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                Text("Words: $words", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                Text("\u2248 ${durSec.toTimeString()}", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }

            Spacer(Modifier.height(12.dp))

            // Emotion button
            OutlinedButton(
                onClick = { viewModel.toggleEmotionPicker() },
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentLight),
                border = BorderStroke(1.dp, Accent.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Icon(Icons.Default.EmojiEmotions, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Add Emotion Tags", style = MaterialTheme.typography.labelLarge)
            }
        }

        Spacer(Modifier.height(16.dp))

        // Voice Selector Card
        AppCard(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.toggleVoicePicker() }
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Voice", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Spacer(Modifier.height(4.dp))
                    if (state.selectedVoice != null) {
                        Text(state.selectedVoice!!.displayName, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                        state.selectedVoice!!.description?.let {
                            Text(it, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                    } else {
                        Text("Select a voice", style = MaterialTheme.typography.titleMedium, color = TextMuted)
                    }
                }
                Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextMuted)
            }
        }

        // Voice picker bottom sheet
        if (state.showVoicePicker) {
            VoicePickerSheet(
                onVoiceSelected = { viewModel.onVoiceSelected(it) },
                onDismiss = { viewModel.toggleVoicePicker() },
                currentVoiceId = state.selectedVoice?.id,
            )
        }

        Spacer(Modifier.height(16.dp))

        // Speed control
        AppCard(modifier = Modifier.fillMaxWidth()) {
            Text("Speed", style = MaterialTheme.typography.labelSmall, color = TextMuted)
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { speed ->
                    val selected = state.speed == speed
                    FilterChip(
                        selected = selected,
                        onClick = { viewModel.onSpeedChange(speed) },
                        label = { Text("${speed}x".removeSuffix(".0x") + "x", style = MaterialTheme.typography.labelSmall) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Accent,
                            selectedLabelColor = Color.White,
                            containerColor = Black600,
                            labelColor = TextSecondary,
                        ),
                        shape = RoundedCornerShape(8.dp),
                        border = FilterChipDefaults.filterChipBorder(enabled = true, selected = selected, borderColor = DividerColor, selectedBorderColor = Accent)
                    )
                }
            }
        }

        Spacer(Modifier.height(24.dp))

        // Generation progress
        if (state.isGenerating) {
            AppCard(modifier = Modifier.fillMaxWidth()) {
                Text("Generating voiceover...", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { state.generationProgress },
                    modifier = Modifier.fillMaxWidth().height(4.dp),
                    color = Accent,
                    trackColor = Black600,
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "${(state.generationProgress * 100).toInt()}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = Accent
                )
            }
            Spacer(Modifier.height(16.dp))
        }

        // Generate button
        GradientButton(
            text = if (state.isGenerating) "Generating..." else "GENERATE VOICE",
            onClick = { viewModel.generateVoice() },
            modifier = Modifier.fillMaxWidth(),
            enabled = !state.isGenerating && state.script.isNotBlank() && state.selectedVoice != null,
            isLoading = state.isGenerating,
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoicePickerSheet(
    onVoiceSelected: (com.twelvelabs.app.domain.model.Voice) -> Unit,
    onDismiss: () -> Unit,
    currentVoiceId: String?,
) {
    val viewModel: com.twelvelabs.app.ui.voices.VoicesViewModel = hiltViewModel()
    val voicesState by viewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) { viewModel.loadVoices() }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Black800,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
        ) {
            Text("Select Voice", style = MaterialTheme.typography.titleLarge, color = TextPrimary, modifier = Modifier.padding(bottom = 16.dp))
            voicesState.voices.forEach { voice ->
                val isSelected = voice.id == currentVoiceId
                Surface(
                    onClick = { onVoiceSelected(voice) },
                    color = if (isSelected) Accent.copy(alpha = 0.15f) else Black700,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(voice.displayName, style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                            voice.description?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = TextSecondary) }
                        }
                        if (isSelected) Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Accent)
                    }
                }
            }
        }
    }
}
''')

# ── Voices Screen ──────────────────────────────────────────────────────────
w(f'{BASE}/ui/voices/VoicesViewModel.kt', '''
package com.twelvelabs.app.ui.voices

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.twelvelabs.app.data.repository.VoiceRepository
import com.twelvelabs.app.domain.model.Voice
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class VoicesUiState(
    val voices: List<Voice> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val playingVoiceId: String? = null,
    val selectedVoiceId: String? = null,
)

@HiltViewModel
class VoicesViewModel @Inject constructor(
    private val voiceRepo: VoiceRepository,
) : ViewModel() {
    private val _uiState = MutableStateFlow(VoicesUiState())
    val uiState: StateFlow<VoicesUiState> = _uiState.asStateFlow()

    init { loadVoices() }

    fun loadVoices() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            voiceRepo.getVoices()
                .onSuccess { voices -> _uiState.update { it.copy(voices = voices, isLoading = false) } }
                .onFailure { e -> _uiState.update { it.copy(isLoading = false, error = "Failed to load voices.") } }
        }
    }

    fun selectVoice(voiceId: String) {
        _uiState.update { it.copy(selectedVoiceId = voiceId) }
    }

    fun setPlayingVoice(voiceId: String?) {
        _uiState.update { it.copy(playingVoiceId = voiceId) }
    }

    fun dismissError() { _uiState.update { it.copy(error = null) } }
}
''')

w(f'{BASE}/ui/voices/VoicesScreen.kt', '''
package com.twelvelabs.app.ui.voices

import android.net.Uri
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import com.twelvelabs.app.domain.model.Voice
import com.twelvelabs.app.ui.components.*
import com.twelvelabs.app.ui.theme.*

@Composable
fun VoicesScreen(viewModel: VoicesViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // ExoPlayer for preview audio
    val exoPlayer = remember {
        ExoPlayer.Builder(context).build()
    }
    DisposableEffect(Unit) {
        onDispose { exoPlayer.release() }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Black900)
    ) {
        // Top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column {
                Text("Voices", style = MaterialTheme.typography.headlineLarge, color = TextPrimary, fontWeight = FontWeight.Bold)
                Text("${state.voices.size} voices available", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
            if (state.isLoading) CircularProgressIndicator(modifier = Modifier.size(24.dp), color = Accent, strokeWidth = 2.dp)
        }

        state.error?.let { ErrorBanner(it, onDismiss = viewModel::dismissError) }

        if (state.isLoading && state.voices.isEmpty()) {
            LoadingIndicator("Loading voices...")
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(state.voices, key = { it.id }) { voice ->
                    VoiceCard(
                        voice = voice,
                        isSelected = state.selectedVoiceId == voice.id,
                        isPlaying = state.playingVoiceId == voice.id,
                        onSelect = { viewModel.selectVoice(voice.id) },
                        onPreview = {
                            if (state.playingVoiceId == voice.id) {
                                exoPlayer.stop()
                                viewModel.setPlayingVoice(null)
                            } else {
                                voice.previewUrl?.let { url ->
                                    exoPlayer.setMediaItem(MediaItem.fromUri(url))
                                    exoPlayer.prepare()
                                    exoPlayer.play()
                                    viewModel.setPlayingVoice(voice.id)
                                }
                            }
                        }
                    )
                }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }
    }
}

@Composable
fun VoiceCard(
    voice: Voice,
    isSelected: Boolean,
    isPlaying: Boolean,
    onSelect: () -> Unit,
    onPreview: () -> Unit,
) {
    Surface(
        color = if (isSelected) Accent.copy(alpha = 0.12f) else Black700,
        shape = RoundedCornerShape(14.dp),
        border = if (isSelected) BorderStroke(1.5.dp, Accent) else BorderStroke(1.dp, DividerColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(voice.displayName, style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                        if (voice.tierRequired != "free") {
                            Surface(
                                color = Accent.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    voice.tierRequired.uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AccentLight,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    voice.description?.let {
                        Spacer(Modifier.height(2.dp))
                        Text(it, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                    voice.accent?.let {
                        Text(it, style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                // Preview button
                OutlinedButton(
                    onClick = onPreview,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = if (isPlaying) Accent else TextSecondary
                    ),
                    border = BorderStroke(1.dp, if (isPlaying) Accent else DividerColor),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(if (isPlaying) "Stop" else "Preview", style = MaterialTheme.typography.labelMedium)
                }

                // Select button
                Button(
                    onClick = onSelect,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) Accent else Black500,
                        contentColor = Color.White,
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    if (isSelected) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                    }
                    Text(if (isSelected) "Selected" else "Select", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}
''')

# ── Audio Player Sheet ────────────────────────────────────────────────────
w(f'{BASE}/ui/player/AudioPlayerSheet.kt', '''
package com.twelvelabs.app.ui.player

import android.content.Context
import android.content.Intent
import android.os.Environment
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.twelvelabs.app.ui.theme.*
import kotlinx.coroutines.delay
imx.coroutines.isActive
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AudioPlayerSheet(
    audioUrl: String,
    projectName: String,
    onDismiss: () -> Unit,
    onDownload: (() -> Unit)? = null,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().also { player ->
            player.setMediaItem(MediaItem.fromUri(audioUrl))
            player.prepare()
        }
    }
    DisposableEffect(Unit) {
        onDispose { exoPlayer.release() }
    }

    var isPlaying by remember { mutableStateOf(false) }
    var currentPositionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var speed by remember { mutableFloatStateOf(1f) }

    // Update position tick
    LaunchedEffect(exoPlayer) {
        while (isActive) {
            currentPositionMs = exoPlayer.currentPosition
            durationMs = exoPlayer.duration.coerceAtLeast(0L)
            isPlaying = exoPlayer.isPlaying
            delay(250)
        }
    }

    DisposableEffect(speed) {
        exoPlayer.setPlaybackSpeed(speed)
        onDispose { }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Black800,
        dragHandle = { BottomSheetDefaults.DragHandle(color = TextMuted) },
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 40.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Your Voiceover", style = MaterialTheme.typography.titleLarge, color = TextPrimary, fontWeight = FontWeight.Bold)
            Text(projectName, style = MaterialTheme.typography.bodySmall, color = TextSecondary)

            Spacer(Modifier.height(24.dp))

            // Timeline
            val progress = if (durationMs > 0) currentPositionMs.toFloat() / durationMs else 0f
            Slider(
                value = progress,
                onValueChange = { p -> exoPlayer.seekTo((p * durationMs).toLong()) },
                modifier = Modifier.fillMaxWidth(),
                colors = SliderDefaults.colors(
                    thumbColor = Accent,
                    activeTrackColor = Accent,
                    inactiveTrackColor = Black500,
                )
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(formatMs(currentPositionMs), style = MaterialTheme.typography.labelSmall, color = TextMuted)
                Text(formatMs(durationMs), style = MaterialTheme.typography.labelSmall, color = TextMuted)
            }

            Spacer(Modifier.height(16.dp))

            // Main controls
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(onClick = { exoPlayer.seekTo(0); exoPlayer.play() }) {
                    Icon(Icons.Default.Replay, contentDescription = "Restart", tint = TextSecondary, modifier = Modifier.size(28.dp))
                }

                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(Accent),
                    contentAlignment = Alignment.Center
                ) {
                    IconButton(onClick = {
                        if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                    }) {
                        Icon(
                            if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = Color.White,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }

                IconButton(onClick = {
                    onDownload?.invoke() ?: downloadAudio(context, audioUrl, projectName)
                }) {
                    Icon(Icons.Default.Download, contentDescription = "Download", tint = TextSecondary, modifier = Modifier.size(28.dp))
                }
            }

            Spacer(Modifier.height(20.dp))

            // Playback speed
            Text("Speed", style = MaterialTheme.typography.labelSmall, color = TextMuted, modifier = Modifier.align(Alignment.Start))
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { s ->
                    val sel = speed == s
                    FilterChip(
                        selected = sel,
                        onClick = { speed = s },
                        label = { Text("${s}x".let { if (it == "1.0x") "1x" else it.replace(".0x", "x") }, style = MaterialTheme.typography.labelSmall) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Accent,
                            selectedLabelColor = Color.White,
                            containerColor = Black600,
                            labelColor = TextSecondary,
                        ),
                        shape = RoundedCornerShape(6.dp),
                        border = FilterChipDefaults.filterChipBorder(enabled = true, selected = sel, borderColor = DividerColor)
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // Share button
            OutlinedButton(
                onClick = { shareAudio(context, audioUrl, projectName) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary),
                border = BorderStroke(1.dp, DividerColor)
            ) {
                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Share Audio")
            }
        }
    }
}

private fun formatMs(ms: Long): String {
    val totalSeconds = ms / 1000
    return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}

private fun downloadAudio(context: Context, url: String, projectName: String) {
    val sanitized = projectName.replace("[^a-zA-Z0-9_]".toRegex(), "_")
    val fileName = "12Labs_${sanitized}.mp3"
    val request = android.app.DownloadManager.Request(android.net.Uri.parse(url))
        .setTitle(fileName)
        .setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
    val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as android.app.DownloadManager
    dm.enqueue(request)
}

private fun shareAudio(context: Context, url: String, projectName: String) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "audio/mpeg"
        putExtra(Intent.EXTRA_SUBJECT, "12Labs Voiceover: $projectName")
        putExtra(Intent.EXTRA_TEXT, url)
    }
    context.startActivity(Intent.createChooser(intent, "Share Voiceover"))
}
''')

# ── Projects Screen ───────────────────────────────────────────────────────
w(f'{BASE}/ui/projects/ProjectsViewModel.kt', '''
package com.twelvelabs.app.ui.projects

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.twelvelabs.app.data.repository.ProjectRepository
import com.twelvelabs.app.domain.model.Project
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ProjectsUiState(
    val projects: List<Project> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val playingProjectUrl: String? = null,
    val showPlayerForProject: Project? = null,
)

@HiltViewModel
class ProjectsViewModel @Inject constructor(
    private val projectRepo: ProjectRepository,
) : ViewModel() {
    private val _uiState = MutableStateFlow(ProjectsUiState())
    val uiState: StateFlow<ProjectsUiState> = _uiState.asStateFlow()

    init {
        // Observe local cache
        viewModelScope.launch {
            projectRepo.observeProjects().collect { projects ->
                _uiState.update { it.copy(projects = projects) }
            }
        }
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            projectRepo.syncProjects()
                .onFailure { _uiState.update { it.copy(error = "Failed to load projects.") } }
            _uiState.update { it.copy(isLoading = false) }
        }
    }

    fun deleteProject(projectId: String) {
        viewModelScope.launch { projectRepo.deleteProject(projectId) }
    }

    fun duplicateProject(projectId: String) {
        viewModelScope.launch { projectRepo.duplicateProject(projectId) }
    }

    fun playProject(project: Project) {
        _uiState.update { it.copy(showPlayerForProject = project) }
    }

    fun dismissPlayer() {
        _uiState.update { it.copy(showPlayerForProject = null) }
    }

    fun dismissError() { _uiState.update { it.copy(error = null) } }
}
''')

w(f'{BASE}/ui/projects/ProjectsScreen.kt', '''
package com.twelvelabs.app.ui.projects

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.twelvelabs.app.domain.model.Project
import com.twelvelabs.app.ui.components.*
import com.twelvelabs.app.ui.player.AudioPlayerSheet
import com.twelvelabs.app.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Locale

@Composable
fun ProjectsScreen(viewModel: ProjectsViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    state.showPlayerForProject?.audioUrl?.let { url ->
        AudioPlayerSheet(
            audioUrl = url,
            projectName = state.showPlayerForProject!!.name,
            onDismiss = { viewModel.dismissPlayer() }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Black900)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Column {
                Text("Projects", style = MaterialTheme.typography.headlineLarge, color = TextPrimary, fontWeight = FontWeight.Bold)
                Text("${state.projects.size} voiceovers", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            }
            IconButton(onClick = { viewModel.refresh() }) {
                if (state.isLoading) CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Accent, strokeWidth = 2.dp)
                else Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = TextSecondary)
            }
        }

        state.error?.let { ErrorBanner(it, onDismiss = viewModel::dismissError) }

        if (state.projects.isEmpty() && !state.isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.FolderOpen, contentDescription = null, tint = TextMuted, modifier = Modifier.size(64.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("No projects yet", style = MaterialTheme.typography.titleMedium, color = TextMuted)
                    Text("Generate a voiceover to get started", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(state.projects, key = { it.id }) { project ->
                    ProjectCard(
                        project = project,
                        onPlay = { viewModel.playProject(project) },
                        onDuplicate = { viewModel.duplicateProject(project.id) },
                        onDelete = { viewModel.deleteProject(project.id) },
                    )
                }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }
    }
}

@Composable
fun ProjectCard(
    project: Project,
    onPlay: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
) {
    var showMenu by remember { mutableStateOf(false) }
    val dateFormat = remember { SimpleDateFormat("MMM d, yyyy", Locale.US) }

    Surface(
        color = Black700,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(project.name, style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(2.dp))
                    Text(
                        buildString {
                            project.audioDurationSeconds?.let { append(formatSeconds(it)).append(" · ") }
                            project.createdAt?.let { append(dateFormat.format(it)) }
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }
                Box {
                    IconButton(onClick = { showMenu = true }, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.MoreVert, contentDescription = null, tint = TextMuted, modifier = Modifier.size(18.dp))
                    }
                    DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }, containerColor = Black600) {
                        DropdownMenuItem(text = { Text("Duplicate", color = TextPrimary) }, onClick = { showMenu = false; onDuplicate() }, leadingIcon = { Icon(Icons.Default.ContentCopy, null, tint = TextSecondary) })
                        DropdownMenuItem(text = { Text("Delete", color = ErrorColor) }, onClick = { showMenu = false; onDelete() }, leadingIcon = { Icon(Icons.Default.Delete, null, tint = ErrorColor) })
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            Text(
                project.script.take(100).let { if (project.script.length > 100) "$it..." else it },
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                maxLines = 2,
            )

            // Status badge
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                StatusBadge(project.status)

                if (project.status == "done" && project.audioUrl != null) {
                    Button(
                        onClick = onPlay,
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Accent),
                    ) {
                        Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Play", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}

@Composable
fun StatusBadge(status: String) {
    val (color, label) = when (status) {
        "done" -> SuccessColor to "Done"
        "generating" -> Accent to "Generating..."
        "failed" -> ErrorColor to "Failed"
        else -> TextMuted to "Draft"
    }
    Surface(color = color.copy(alpha = 0.15f), shape = RoundedCornerShape(4.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = color, modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
    }
}

private fun formatSeconds(seconds: Float): String {
    val s = seconds.toInt()
    return "%d:%02d".format(s / 60, s % 60)
}
''')

# ── Settings Screen ────────────────────────────────────────────────────────
w(f'{BASE}/ui/settings/SettingsScreen.kt', '''
package com.twelvelabs.app.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.twelvelabs.app.ui.theme.*

@Composable
fun SettingsScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Black900)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .padding(top = 16.dp, bottom = 100.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineLarge, color = TextPrimary, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))

        SettingsSection("Generation") {
            SettingsItem(Icons.Default.Speed, "Default Speed", "1.0x")
            SettingsItem(Icons.Default.AudioFile, "Default Format", "MP3")
            SettingsItem(Icons.Default.RecordVoiceOver, "Default Voice", "Not set")
        }

        Spacer(Modifier.height(16.dp))

        SettingsSection("Account") {
            SettingsItem(Icons.Default.Person, "Account", null)
            SettingsItem(Icons.Default.Star, "Subscription", "Free")
            SettingsItem(Icons.Default.BarChart, "Usage", null)
        }

        Spacer(Modifier.height(16.dp))

        SettingsSection("Storage") {
            SettingsItem(Icons.Default.Folder, "Download Location", "Downloads")
        }

        Spacer(Modifier.height(16.dp))

        SettingsSection("Legal") {
            SettingsItem(Icons.Default.PrivacyTip, "Privacy Policy", null)
            SettingsItem(Icons.Default.Article, "Terms of Service", null)
        }

        Spacer(Modifier.height(16.dp))

        SettingsSection("Danger Zone") {
            SettingsDangerItem(Icons.Default.DeleteForever, "Delete Account")
        }
    }
}

@Composable
fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(title.uppercase(), style = MaterialTheme.typography.labelSmall, color = TextMuted, letterSpacing = androidx.compose.ui.unit.TextUnit.Unspecified)
    Spacer(Modifier.height(8.dp))
    Surface(
        color = Black700,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(content = content)
    }
}

@Composable
fun SettingsItem(icon: ImageVector, label: String, value: String?) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(14.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, color = TextPrimary, modifier = Modifier.weight(1f))
        if (value != null) {
            Text(value, style = MaterialTheme.typography.bodySmall, color = TextMuted)
        }
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextMuted, modifier = Modifier.size(16.dp))
    }
}

@Composable
fun SettingsDangerItem(icon: ImageVector, label: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = ErrorColor, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(14.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, color = ErrorColor, modifier = Modifier.weight(1f))
    }
}
''')

# ── Resources ─────────────────────────────────────────────────────────────
w('app/src/main/res/values/strings.xml', '''
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">12Labs</string>
</resources>
''')

w('app/src/main/res/values/styles.xml', '''
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.TwelveLabs" parent="android:Theme.Material.NoTitleBar">
        <item name="android:windowBackground">@android:color/black</item>
        <item name="android:statusBarColor">@android:color/transparent</item>
        <item name="android:navigationBarColor">@android:color/transparent</item>
    </style>
</resources>
''')

w('app/src/main/res/xml/network_security_config.xml', '''
<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <domain-config cleartextTrafficPermitted="false">
        <domain includeSubdomains="true">api.12labs.app</domain>
    </domain-config>
</network-security-config>
''')

w('app/src/main/res/xml/file_paths.xml', '''
<?xml version="1.0" encoding="utf-8"?>
<paths>
    <external-files-path name="external_files" path="."/>
    <external-path name="external_storage" path="."/>
</paths>
''')

w('app/proguard-rules.pro', '''
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.twelvelabs.app.data.remote.models.** { *; }
-keep class com.google.gson.** { *; }
-keep class retrofit2.** { *; }
-dontwarn retrofit2.**
-keep class okhttp3.** { *; }
-dontwarn okhttp3.**
-keep class com.google.firebase.** { *; }
-keep class com.google.android.gms.** { *; }
''')

print('UI screens done')
