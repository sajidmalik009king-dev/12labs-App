import os

files = {}

# ── models/voice.py ──────────────────────────────────────────────────────────
files['app/models/voice.py'] = '''
import uuid
from datetime import datetime
from sqlalchemy import String, Boolean, Integer, Text, func
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.dialects.postgresql import UUID, JSONB
from app.database import Base


class Voice(Base):
    __tablename__ = "voices"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    display_name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    accent: Mapped[str | None] = mapped_column(String(100))
    provider: Mapped[str] = mapped_column(String(50), default="elevenlabs")
    provider_voice_id: Mapped[str] = mapped_column(String(255), nullable=False)  # NEVER sent to client
    preview_storage_path: Mapped[str | None] = mapped_column(Text)  # internal storage path
    voice_settings: Mapped[dict | None] = mapped_column(JSONB)  # {stability, similarity_boost, style, use_speaker_boost}
    tier_required: Mapped[str] = mapped_column(String(20), default="free")  # free|creator|pro
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(server_default=func.now(), onupdate=func.now())
'''

# ── models/project.py ────────────────────────────────────────────────────────
files['app/models/project.py'] = '''
import uuid
from datetime import datetime
from sqlalchemy import String, Float, Text, ForeignKey, func
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import UUID, JSONB
from app.database import Base


class Project(Base):
    __tablename__ = "projects"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(255), default="Untitled Project")
    script: Mapped[str] = mapped_column(Text, nullable=False)
    voice_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("voices.id", ondelete="SET NULL"))
    voice_settings_override: Mapped[dict | None] = mapped_column(JSONB)
    speed: Mapped[float] = mapped_column(Float, default=1.0)
    emotion_tags: Mapped[list | None] = mapped_column(JSONB)
    audio_storage_path: Mapped[str | None] = mapped_column(Text)
    audio_duration_seconds: Mapped[float | None] = mapped_column(Float)
    audio_format: Mapped[str] = mapped_column(String(10), default="mp3")
    status: Mapped[str] = mapped_column(String(20), default="draft")  # draft|generating|done|failed
    chars_used: Mapped[int | None] = mapped_column()
    created_at: Mapped[datetime] = mapped_column(server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(server_default=func.now(), onupdate=func.now())

    user: Mapped["User"] = relationship("User", back_populates="projects")
    voice: Mapped["Voice | None"] = relationship("Voice")
    generation_jobs: Mapped[list["GenerationJob"]] = relationship("GenerationJob", back_populates="project", cascade="all, delete-orphan")


class GenerationJob(Base):
    __tablename__ = "generation_jobs"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    project_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"))
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    status: Mapped[str] = mapped_column(String(20), default="pending")  # pending|processing|done|failed
    chunks_total: Mapped[int | None] = mapped_column()
    chunks_done: Mapped[int] = mapped_column(default=0)
    error_message: Mapped[str | None] = mapped_column(Text)
    started_at: Mapped[datetime | None] = mapped_column()
    completed_at: Mapped[datetime | None] = mapped_column()
    created_at: Mapped[datetime] = mapped_column(server_default=func.now())

    project: Mapped["Project"] = relationship("Project", back_populates="generation_jobs")
'''

# ── models/usage.py ───────────────────────────────────────────────────────────
files['app/models/usage.py'] = '''
import uuid
from datetime import datetime
from sqlalchemy import String, Integer, Float, Text, ForeignKey, func
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import UUID
from app.database import Base


class UsageEvent(Base):
    __tablename__ = "usage_events"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), index=True)
    project_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("projects.id", ondelete="SET NULL"))
    chars_used: Mapped[int] = mapped_column(Integer, nullable=False)
    audio_duration_seconds: Mapped[float | None] = mapped_column(Float)
    provider: Mapped[str | None] = mapped_column(String(50))
    created_at: Mapped[datetime] = mapped_column(server_default=func.now())

    user: Mapped["User"] = relationship("User", back_populates="usage_events")


class PronunciationRule(Base):
    __tablename__ = "pronunciation_rules"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), index=True)
    word: Mapped[str] = mapped_column(String(200), nullable=False)
    pronunciation: Mapped[str] = mapped_column(String(500), nullable=False)
    created_at: Mapped[datetime] = mapped_column(server_default=func.now())

    user: Mapped["User"] = relationship("User", back_populates="pronunciation_rules")
'''

# ── models/__init__.py ────────────────────────────────────────────────────────
files['app/models/__init__.py'] = '''
from app.models.user import User
from app.models.voice import Voice
from app.models.project import Project, GenerationJob
from app.models.usage import UsageEvent, PronunciationRule

__all__ = ["User", "Voice", "Project", "GenerationJob", "UsageEvent", "PronunciationRule"]
'''

# ── services/emotion_parser.py ────────────────────────────────────────────────
files['app/services/emotion_parser.py'] = '''
import re
from dataclasses import dataclass
from enum import Enum
from typing import Any


class SupportLevel(str, Enum):
    NATIVE = "native"          # ElevenLabs handles it natively
    APPROXIMATED = "approximated"  # We approximate via settings
    FALLBACK = "fallback"      # We insert silence / ignore
    UNSUPPORTED = "unsupported"


class SegmentType(str, Enum):
    TEXT = "text"
    ACTION = "action"


@dataclass
class Segment:
    type: SegmentType
    content: str = ""          # For TEXT segments
    tag: str = ""              # Original bracket tag (normalized)
    support: SupportLevel = SupportLevel.FALLBACK
    implementation: str = ""   # How it\'s implemented
    params: dict = None        # Extra params (duration_ms, settings, etc.)

    def to_dict(self) -> dict:
        d = {
            "type": self.type.value,
            "content": self.content,
            "tag": self.tag,
            "support": self.support.value if self.support else None,
            "implementation": self.implementation,
            "params": self.params or {},
        }
        return {k: v for k, v in d.items() if v is not None and v != ""}


# ElevenLabs capability map
# Keys: normalized lowercase tag text
EMOTION_CAPABILITIES: dict[str, dict[str, Any]] = {
    # Pauses — native via SSML break
    "pause":       {"support": SupportLevel.NATIVE, "impl": "ssml_break", "params": {"duration_ms": 500}},
    "short pause": {"support": SupportLevel.NATIVE, "impl": "ssml_break", "params": {"duration_ms": 300}},
    "long pause":  {"support": SupportLevel.NATIVE, "impl": "ssml_break", "params": {"duration_ms": 1500}},

    # Delivery approximated via voice settings
    "whispers":    {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.25, "similarity_boost": 0.9, "style": 0.8}},
    "whisper":     {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.25, "similarity_boost": 0.9, "style": 0.8}},
    "softly":      {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.7, "similarity_boost": 0.8, "style": 0.3}},
    "softly":      {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.7, "similarity_boost": 0.8, "style": 0.3}},
    "quietly":     {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.6, "similarity_boost": 0.75, "style": 0.2}},
    "slowly":      {"support": SupportLevel.APPROXIMATED, "impl": "speed_override",
                    "params": {"speed": 0.75}},
    "firmly":      {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.85, "similarity_boost": 0.9, "style": 0.5}},
    "dramatically":{"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.2, "similarity_boost": 0.95, "style": 0.95}},

    # Emotions — approximated
    "excited":     {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.15, "similarity_boost": 0.95, "style": 0.9}},
    "happy":       {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.4, "similarity_boost": 0.9, "style": 0.7}},
    "sad":         {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.8, "similarity_boost": 0.6, "style": 0.2}},
    "sadly":       {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.8, "similarity_boost": 0.6, "style": 0.2}},
    "angry":       {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.1, "similarity_boost": 0.95, "style": 0.95}},
    "angrily":     {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.1, "similarity_boost": 0.95, "style": 0.95}},
    "nervous":     {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.3, "similarity_boost": 0.85, "style": 0.6}},
    "scared":      {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.2, "similarity_boost": 0.9, "style": 0.75}},
    "confused":    {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.4, "similarity_boost": 0.8, "style": 0.5}},
    "shocked":     {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.1, "similarity_boost": 0.95, "style": 0.9}},
    "serious":     {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.9, "similarity_boost": 0.85, "style": 0.1}},
    "calm":        {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.95, "similarity_boost": 0.75, "style": 0.05}},
    "confident":   {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.8, "similarity_boost": 0.95, "style": 0.5}},
    "concerned":   {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.6, "similarity_boost": 0.8, "style": 0.4}},

    # Vocal actions — fallback (insert short pause at minimum)
    "chuckles":    {"support": SupportLevel.FALLBACK, "impl": "ssml_break", "params": {"duration_ms": 400}},
    "laughs":      {"support": SupportLevel.FALLBACK, "impl": "ssml_break", "params": {"duration_ms": 600}},
    "laughs softly": {"support": SupportLevel.FALLBACK, "impl": "ssml_break", "params": {"duration_ms": 500}},
    "sighs":       {"support": SupportLevel.FALLBACK, "impl": "ssml_break", "params": {"duration_ms": 700}},
    "deep breath": {"support": SupportLevel.FALLBACK, "impl": "ssml_break", "params": {"duration_ms": 1000}},
    "gasps":       {"support": SupportLevel.FALLBACK, "impl": "ssml_break", "params": {"duration_ms": 300}},
    "clears throat": {"support": SupportLevel.FALLBACK, "impl": "ssml_break", "params": {"duration_ms": 400}},
}

BRACKET_RE = re.compile(r"\[([^\]]+)\]")


def parse_script(script: str) -> list[Segment]:
    """
    Parse a script with emotion tags into a list of Segment objects.
    Text between tags becomes TEXT segments.
    Bracket content becomes ACTION segments.
    """
    segments: list[Segment] = []
    last_end = 0

    for match in BRACKET_RE.finditer(script):
        # Text before this bracket
        text_before = script[last_end:match.start()].strip()
        if text_before:
            segments.append(Segment(type=SegmentType.TEXT, content=text_before))

        tag_raw = match.group(1).strip().lower()
        cap = EMOTION_CAPABILITIES.get(tag_raw)
        if cap:
            seg = Segment(
                type=SegmentType.ACTION,
                tag=tag_raw,
                support=cap["support"],
                implementation=cap["impl"],
                params=cap["params"].copy(),
            )
        else:
            # Unknown tag — treat as a short pause fallback, do NOT speak it
            seg = Segment(
                type=SegmentType.ACTION,
                tag=tag_raw,
                support=SupportLevel.FALLBACK,
                implementation="ssml_break",
                params={"duration_ms": 300},
            )
        segments.append(seg)
        last_end = match.end()

    # Remaining text after last bracket
    remaining = script[last_end:].strip()
    if remaining:
        segments.append(Segment(type=SegmentType.TEXT, content=remaining))

    return segments


def segments_to_dict(segments: list[Segment]) -> list[dict]:
    return [s.to_dict() for s in segments]
'''

# ── services/elevenlabs.py ────────────────────────────────────────────────────
files['app/services/elevenlabs.py'] = '''
import asyncio
import httpx
import json
from typing import AsyncIterator
from app.config import settings
from app.services.emotion_parser import Segment, SegmentType, SupportLevel


ELEVENLABS_TTS_URL = "{base}/text-to-speech/{voice_id}"
ELEVENLABS_MODELS = {
    "default": "eleven_turbo_v2_5",  # Fast, high quality
    "multilingual": "eleven_multilingual_v2",
}


class ElevenLabsClient:
    def __init__(self):
        self.api_key = settings.elevenlabs_api_key
        self.base_url = settings.elevenlabs_base_url

    def _headers(self) -> dict:
        return {
            "xi-api-key": self.api_key,
            "Content-Type": "application/json",
            "Accept": "audio/mpeg",
        }

    def _build_request(
        self,
        text: str,
        voice_settings: dict,
        speed: float = 1.0,
        output_format: str = "mp3_44100_128",
    ) -> dict:
        return {
            "text": text,
            "model_id": ELEVENLABS_MODELS["default"],
            "voice_settings": {
                "stability": voice_settings.get("stability", 0.5),
                "similarity_boost": voice_settings.get("similarity_boost", 0.8),
                "style": voice_settings.get("style", 0.0),
                "use_speaker_boost": voice_settings.get("use_speaker_boost", True),
                "speed": speed,
            },
            "output_format": output_format,
        }

    async def synthesize_chunk(
        self,
        text: str,
        provider_voice_id: str,
        voice_settings: dict,
        speed: float = 1.0,
        output_format: str = "mp3_44100_128",
    ) -> bytes:
        """Synthesize a single text chunk, returning raw audio bytes."""
        url = f"{self.base_url}/text-to-speech/{provider_voice_id}"
        payload = self._build_request(text, voice_settings, speed, output_format)

        async with httpx.AsyncClient(timeout=120.0) as client:
            resp = await client.post(url, headers=self._headers(), json=payload)
            if resp.status_code == 422:
                raise ValueError(f"ElevenLabs validation error: {resp.text}")
            if resp.status_code == 429:
                raise RuntimeError("ElevenLabs rate limit exceeded. Please try again.")
            resp.raise_for_status()
            return resp.content

    async def synthesize_segments(
        self,
        segments: list[Segment],
        provider_voice_id: str,
        base_voice_settings: dict,
        speed: float = 1.0,
    ) -> list[tuple[str, bytes | int]]:
        """
        Process segments and return a list of (type, data) tuples:
        - ("audio", bytes)  — synthesized audio
        - ("silence", ms)   — duration in ms to insert as silence
        """
        results = []
        current_text = []
        current_settings = base_voice_settings.copy()
        current_speed = speed
        pending_settings_override = None
        pending_speed_override = None

        async def flush_text():
            nonlocal current_text
            combined = " ".join(current_text).strip()
            if combined:
                s = pending_settings_override or current_settings
                sp = pending_speed_override or current_speed
                audio = await self.synthesize_chunk(
                    combined, provider_voice_id, s, sp
                )
                results.append(("audio", audio))
                current_text = []

        for seg in segments:
            if seg.type == SegmentType.TEXT:
                current_text.append(seg.content)
            elif seg.type == SegmentType.ACTION:
                if seg.implementation == "ssml_break":
                    # Flush accumulated text first
                    await flush_text()
                    results.append(("silence", seg.params.get("duration_ms", 500)))
                elif seg.implementation == "settings_override":
                    # Flush current text, then next text uses overridden settings
                    await flush_text()
                    pending_settings_override = {**base_voice_settings, **seg.params}
                elif seg.implementation == "speed_override":
                    await flush_text()
                    pending_speed_override = seg.params.get("speed", 0.75)

        await flush_text()
        return results


elevenlabs_client = ElevenLabsClient()
'''

# ── services/audio_processor.py ───────────────────────────────────────────────
files['app/services/audio_processor.py'] = '''
import asyncio
import io
import subprocess
import tempfile
import os
from pathlib import Path


async def generate_silence_bytes(duration_ms: int) -> bytes:
    """Generate PCM silence of given duration, encoded as MP3."""
    cmd = [
        "ffmpeg", "-f", "lavfi",
        "-i", f"anullsrc=r=44100:cl=mono",
        "-t", str(duration_ms / 1000),
        "-acodec", "libmp3lame",
        "-ab", "128k",
        "-f", "mp3",
        "pipe:1"
    ]
    proc = await asyncio.create_subprocess_exec(
        *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await proc.communicate()
    if proc.returncode != 0:
        raise RuntimeError(f"ffmpeg silence error: {stderr.decode()[:200]}")
    return stdout


async def stitch_audio_chunks(chunks: list[tuple[str, bytes | int]]) -> bytes:
    """
    Stitch (type, data) chunks into one MP3.
    type = "audio" -> bytes of MP3
    type = "silence" -> int milliseconds
    """
    with tempfile.TemporaryDirectory() as tmpdir:
        segment_files = []
        for i, (chunk_type, data) in enumerate(chunks):
            path = os.path.join(tmpdir, f"seg_{i:04d}.mp3")
            if chunk_type == "audio":
                with open(path, "wb") as f:
                    f.write(data)
            elif chunk_type == "silence":
                silence = await generate_silence_bytes(int(data))
                with open(path, "wb") as f:
                    f.write(silence)
            segment_files.append(path)

        if not segment_files:
            return b""

        if len(segment_files) == 1:
            with open(segment_files[0], "rb") as f:
                return f.read()

        # Write concat list file
        list_path = os.path.join(tmpdir, "concat.txt")
        with open(list_path, "w") as f:
            for p in segment_files:
                f.write(f"file \'{p}\'\n")

        output_path = os.path.join(tmpdir, "output.mp3")
        cmd = [
            "ffmpeg", "-f", "concat",
            "-safe", "0",
            "-i", list_path,
            "-c", "copy",
            output_path
        ]
        proc = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await proc.communicate()
        if proc.returncode != 0:
            raise RuntimeError(f"ffmpeg concat error: {stderr.decode()[:500]}")

        with open(output_path, "rb") as f:
            return f.read()


async def get_audio_duration(audio_bytes: bytes) -> float:
    """Return duration in seconds of an MP3 byte string."""
    with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as tmp:
        tmp.write(audio_bytes)
        tmp_path = tmp.name
    try:
        cmd = [
            "ffprobe", "-v", "quiet",
            "-show_entries", "format=duration",
            "-of", "csv=p=0",
            tmp_path
        ]
        proc = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        stdout, _ = await proc.communicate()
        return float(stdout.decode().strip() or "0")
    finally:
        os.unlink(tmp_path)


def chunk_script(script: str, max_chars: int = 2500) -> list[str]:
    """
    Split a long script into chunks <= max_chars,
    splitting on paragraph > sentence > word boundaries.
    Preserves [emotion tags] within their owning paragraph.
    """
    paragraphs = [p.strip() for p in script.split("\n\n") if p.strip()]
    chunks = []
    current = ""

    for para in paragraphs:
        candidate = (current + "\n\n" + para).strip() if current else para
        if len(candidate) <= max_chars:
            current = candidate
        else:
            # Paragraph itself too long — split on sentences
            if current:
                chunks.append(current)
                current = ""
            sentences = _split_sentences(para)
            for sent in sentences:
                candidate2 = (current + " " + sent).strip() if current else sent
                if len(candidate2) <= max_chars:
                    current = candidate2
                else:
                    if current:
                        chunks.append(current)
                    current = sent  # May still be long — accept as-is
    if current:
        chunks.append(current)
    return chunks


import re
_SENT_RE = re.compile(r\'(?<=[.!?])\\s+\')


def _split_sentences(text: str) -> list[str]:
    return [s.strip() for s in _SENT_RE.split(text) if s.strip()]
'''

# ── services/storage.py ───────────────────────────────────────────────────────
files['app/services/storage.py'] = '''
import io
import os
import uuid
from datetime import datetime
import boto3
from botocore.config import Config
from botocore.exceptions import ClientError
from app.config import settings


class StorageService:
    def __init__(self):
        self._client = None

    def _get_client(self):
        if self._client is None:
            kwargs = dict(
                region_name=settings.s3_region,
                aws_access_key_id=settings.s3_access_key,
                aws_secret_access_key=settings.s3_secret_key,
            )
            if settings.s3_endpoint_url:
                kwargs["endpoint_url"] = settings.s3_endpoint_url
            self._client = boto3.client("s3", **kwargs, config=Config(signature_version="s3v4"))
        return self._client

    def upload_audio(
        self,
        audio_bytes: bytes,
        user_id: str,
        project_id: str,
        fmt: str = "mp3",
    ) -> str:
        """Upload audio bytes and return the storage path (key)."""
        key = f"audio/{user_id}/{project_id}/voiceover.{fmt}"
        content_type = "audio/mpeg" if fmt == "mp3" else "audio/wav"
        self._get_client().put_object(
            Bucket=settings.s3_bucket,
            Key=key,
            Body=audio_bytes,
            ContentType=content_type,
        )
        return key

    def upload_preview(
        self,
        audio_bytes: bytes,
        voice_id: str,
    ) -> str:
        """Upload a voice preview file and return storage path."""
        key = f"voices/previews/{voice_id}/preview.mp3"
        self._get_client().put_object(
            Bucket=settings.s3_bucket,
            Key=key,
            Body=audio_bytes,
            ContentType="audio/mpeg",
        )
        return key

    def generate_presigned_url(self, storage_path: str, expiry: int | None = None) -> str:
        """Generate a pre-signed URL for a stored object."""
        if expiry is None:
            expiry = settings.audio_url_expiry
        return self._get_client().generate_presigned_url(
            "get_object",
            Params={"Bucket": settings.s3_bucket, "Key": storage_path},
            ExpiresIn=expiry,
        )

    def delete_object(self, storage_path: str):
        try:
            self._get_client().delete_object(Bucket=settings.s3_bucket, Key=storage_path)
        except ClientError:
            pass  # Already deleted or doesn\'t exist


storage_service = StorageService()
'''

# ── services/usage_tracker.py ─────────────────────────────────────────────────
files['app/services/usage_tracker.py'] = '''
from datetime import datetime, timezone
from dateutil.relativedelta import relativedelta
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from app.models.user import User
from app.models.usage import UsageEvent
from app.config import settings, TIER_LIMITS


async def get_chars_limit(user: User) -> int:
    tier = user.subscription_tier or "free"
    return TIER_LIMITS.get(tier, TIER_LIMITS["free"])["chars_per_month"]


async def get_chars_used(db: AsyncSession, user: User) -> int:
    # Reset period if needed
    now = datetime.now(timezone.utc)
    if user.period_reset_at is None or now >= user.period_reset_at:
        user.chars_used_this_period = 0
        user.period_reset_at = (now + relativedelta(months=1)).replace(
            hour=0, minute=0, second=0, microsecond=0
        )
        await db.commit()
        await db.refresh(user)
    return user.chars_used_this_period


async def check_usage(
    db: AsyncSession,
    user: User,
    chars_needed: int,
) -> tuple[bool, int, int]:
    """Returns (ok, chars_used, chars_limit)."""
    used = await get_chars_used(db, user)
    limit = await get_chars_limit(user)
    ok = (used + chars_needed) <= limit
    return ok, used, limit


async def record_usage(
    db: AsyncSession,
    user: User,
    chars_used: int,
    project_id=None,
    audio_duration: float | None = None,
    provider: str = "elevenlabs",
):
    event = UsageEvent(
        user_id=user.id,
        project_id=project_id,
        chars_used=chars_used,
        audio_duration_seconds=audio_duration,
        provider=provider,
    )
    db.add(event)
    user.chars_used_this_period = (user.chars_used_this_period or 0) + chars_used
    await db.commit()
'''

# ── middleware/auth.py ────────────────────────────────────────────────────────
files['app/middleware/auth.py'] = '''
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
import firebase_admin
from firebase_admin import auth as firebase_auth, credentials
from app.database import get_db
from app.models.user import User
from app.config import settings
import json
import os

_firebase_initialized = False


def _init_firebase():
    global _firebase_initialized
    if _firebase_initialized:
        return
    try:
        cred_value = settings.firebase_service_account_json
        if os.path.isfile(cred_value):
            cred = credentials.Certificate(cred_value)
        else:
            cred = credentials.Certificate(json.loads(cred_value))
        firebase_admin.initialize_app(cred)
        _firebase_initialized = True
    except Exception as e:
        print(f"Firebase init warning: {e}")


_init_firebase()

security = HTTPBearer(auto_error=True)


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db),
) -> User:
    token = credentials.credentials
    try:
        decoded = firebase_auth.verify_id_token(token)
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token.",
        )

    firebase_uid = decoded["uid"]
    result = await db.execute(select(User).where(User.firebase_uid == firebase_uid))
    user = result.scalar_one_or_none()

    if user is None:
        user = User(
            firebase_uid=firebase_uid,
            email=decoded.get("email"),
            display_name=decoded.get("name"),
        )
        db.add(user)
        await db.commit()
        await db.refresh(user)

    if not user.is_active:
        raise HTTPException(status_code=403, detail="Account is disabled.")

    return user
'''

# ── routers/voices.py ─────────────────────────────────────────────────────────
files['app/routers/voices.py'] = '''
import uuid
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from app.database import get_db
from app.models.voice import Voice
from app.models.user import User
from app.middleware.auth import get_current_user
from app.services.storage import storage_service
from app.config import settings

router = APIRouter(prefix="/voices", tags=["voices"])


class VoiceResponse(BaseModel):
    id: str
    display_name: str
    description: str | None
    accent: str | None
    tier_required: str
    preview_url: str | None  # signed URL — never the storage path directly

    class Config:
        from_attributes = True


@router.get("", response_model=list[VoiceResponse])
async def list_voices(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(Voice)
        .where(Voice.is_active == True)
        .order_by(Voice.sort_order, Voice.display_name)
    )
    voices = result.scalars().all()

    out = []
    for v in voices:
        preview_url = None
        if v.preview_storage_path:
            try:
                preview_url = storage_service.generate_presigned_url(
                    v.preview_storage_path,
                    expiry=settings.preview_url_expiry,
                )
            except Exception:
                pass
        out.append(VoiceResponse(
            id=str(v.id),
            display_name=v.display_name,
            description=v.description,
            accent=v.accent,
            tier_required=v.tier_required,
            preview_url=preview_url,
        ))
    return out
'''

# ── routers/projects.py ───────────────────────────────────────────────────────
files['app/routers/projects.py'] = '''
import uuid
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from app.database import get_db
from app.models.project import Project
from app.models.user import User
from app.middleware.auth import get_current_user
from app.services.storage import storage_service

router = APIRouter(prefix="/projects", tags=["projects"])


class ProjectCreate(BaseModel):
    name: str = "Untitled Project"
    script: str = ""
    voice_id: str | None = None
    speed: float = 1.0
    audio_format: str = "mp3"


class ProjectUpdate(BaseModel):
    name: str | None = None
    script: str | None = None
    voice_id: str | None = None
    speed: float | None = None


class ProjectResponse(BaseModel):
    id: str
    name: str
    script: str
    voice_id: str | None
    speed: float
    audio_format: str
    status: str
    audio_url: str | None
    audio_duration_seconds: float | None
    chars_used: int | None
    created_at: datetime
    updated_at: datetime


def _project_to_response(p: Project) -> ProjectResponse:
    audio_url = None
    if p.audio_storage_path and p.status == "done":
        try:
            audio_url = storage_service.generate_presigned_url(p.audio_storage_path)
        except Exception:
            pass
    return ProjectResponse(
        id=str(p.id),
        name=p.name,
        script=p.script,
        voice_id=str(p.voice_id) if p.voice_id else None,
        speed=p.speed,
        audio_format=p.audio_format,
        status=p.status,
        audio_url=audio_url,
        audio_duration_seconds=p.audio_duration_seconds,
        chars_used=p.chars_used,
        created_at=p.created_at,
        updated_at=p.updated_at,
    )


@router.get("", response_model=list[ProjectResponse])
async def list_projects(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    limit: int = 50,
    offset: int = 0,
):
    result = await db.execute(
        select(Project)
        .where(Project.user_id == user.id)
        .order_by(Project.updated_at.desc())
        .limit(limit)
        .offset(offset)
    )
    projects = result.scalars().all()
    return [_project_to_response(p) for p in projects]


@router.post("", response_model=ProjectResponse, status_code=201)
async def create_project(
    body: ProjectCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    project = Project(
        user_id=user.id,
        name=body.name,
        script=body.script,
        voice_id=uuid.UUID(body.voice_id) if body.voice_id else None,
        speed=body.speed,
        audio_format=body.audio_format,
    )
    db.add(project)
    await db.commit()
    await db.refresh(project)
    return _project_to_response(project)


@router.get("/{project_id}", response_model=ProjectResponse)
async def get_project(
    project_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    p = await _get_or_404(db, project_id, user.id)
    return _project_to_response(p)


@router.put("/{project_id}", response_model=ProjectResponse)
async def update_project(
    project_id: str,
    body: ProjectUpdate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    p = await _get_or_404(db, project_id, user.id)
    if body.name is not None:
        p.name = body.name
    if body.script is not None:
        p.script = body.script
    if body.voice_id is not None:
        p.voice_id = uuid.UUID(body.voice_id)
    if body.speed is not None:
        p.speed = body.speed
    await db.commit()
    await db.refresh(p)
    return _project_to_response(p)


@router.delete("/{project_id}", status_code=204)
async def delete_project(
    project_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    p = await _get_or_404(db, project_id, user.id)
    if p.audio_storage_path:
        try:
            storage_service.delete_object(p.audio_storage_path)
        except Exception:
            pass
    await db.delete(p)
    await db.commit()


@router.post("/{project_id}/duplicate", response_model=ProjectResponse, status_code=201)
async def duplicate_project(
    project_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    p = await _get_or_404(db, project_id, user.id)
    new_p = Project(
        user_id=user.id,
        name=p.name + " (Copy)",
        script=p.script,
        voice_id=p.voice_id,
        speed=p.speed,
        audio_format=p.audio_format,
        status="draft",
    )
    db.add(new_p)
    await db.commit()
    await db.refresh(new_p)
    return _project_to_response(new_p)


async def _get_or_404(db: AsyncSession, project_id: str, user_id) -> Project:
    try:
        pid = uuid.UUID(project_id)
    except ValueError:
        raise HTTPException(status_code=404, detail="Project not found.")
    result = await db.execute(
        select(Project).where(Project.id == pid, Project.user_id == user_id)
    )
    p = result.scalar_one_or_none()
    if not p:
        raise HTTPException(status_code=404, detail="Project not found.")
    return p
'''

# ── routers/generate.py ───────────────────────────────────────────────────────
files['app/routers/generate.py'] = '''
import uuid
import asyncio
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from app.database import get_db, AsyncSessionLocal
from app.models.project import Project, GenerationJob
from app.models.voice import Voice
from app.models.user import User
from app.middleware.auth import get_current_user
from app.services.emotion_parser import parse_script
from app.services.elevenlabs import elevenlabs_client
from app.services.audio_processor import stitch_audio_chunks, get_audio_duration, chunk_script
from app.services.storage import storage_service
from app.services.usage_tracker import check_usage, record_usage
from app.config import settings, TIER_LIMITS

router = APIRouter(prefix="/generate", tags=["generate"])


class GenerateRequest(BaseModel):
    project_id: str
    voice_id: str
    script: str
    speed: float = 1.0
    audio_format: str = "mp3"  # mp3 | wav
    voice_settings_override: dict | None = None


class GenerateResponse(BaseModel):
    job_id: str
    status: str
    message: str


class JobStatusResponse(BaseModel):
    job_id: str
    status: str
    progress: float
    audio_url: str | None
    error: str | None


@router.post("", response_model=GenerateResponse)
async def start_generation(
    body: GenerateRequest,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    # Validate format access
    allowed_formats = TIER_LIMITS.get(user.subscription_tier, TIER_LIMITS["free"])["formats"]
    if body.audio_format not in allowed_formats:
        raise HTTPException(
            status_code=403,
            detail=f"Your plan does not support {body.audio_format.upper()} export. Upgrade to access this feature.",
        )

    # Validate project ownership
    try:
        pid = uuid.UUID(body.project_id)
    except ValueError:
        raise HTTPException(status_code=404, detail="Project not found.")
    result = await db.execute(select(Project).where(Project.id == pid, Project.user_id == user.id))
    project = result.scalar_one_or_none()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found.")

    # Validate voice
    try:
        vid = uuid.UUID(body.voice_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid voice ID.")
    v_result = await db.execute(select(Voice).where(Voice.id == vid, Voice.is_active == True))
    voice = v_result.scalar_one_or_none()
    if not voice:
        raise HTTPException(status_code=404, detail="Voice not found or unavailable.")

    # Check voice tier access
    tier_order = {"free": 0, "creator": 1, "pro": 2}
    if tier_order.get(voice.tier_required, 0) > tier_order.get(user.subscription_tier, 0):
        raise HTTPException(status_code=403, detail="This voice requires a higher subscription tier.")

    # Check usage
    clean_script = body.script.strip()
    chars_needed = len(clean_script)
    ok, chars_used, chars_limit = await check_usage(db, user, chars_needed)
    if not ok:
        raise HTTPException(
            status_code=402,
            detail=f"Character limit exceeded. Used: {chars_used}/{chars_limit}. Upgrade for more.",
        )

    # Create generation job
    job = GenerationJob(
        project_id=project.id,
        user_id=user.id,
        status="pending",
    )
    db.add(job)
    project.status = "generating"
    await db.commit()
    await db.refresh(job)

    # Fire background task
    background_tasks.add_task(
        _run_generation,
        job_id=str(job.id),
        project_id=str(project.id),
        user_id=str(user.id),
        voice_provider_id=voice.provider_voice_id,
        base_settings=voice.voice_settings or {},
        override_settings=body.voice_settings_override,
        script=clean_script,
        speed=body.speed,
        audio_format=body.audio_format,
        chars_needed=chars_needed,
    )

    return GenerateResponse(
        job_id=str(job.id),
        status="pending",
        message="Generation started.",
    )


async def _run_generation(
    job_id: str,
    project_id: str,
    user_id: str,
    voice_provider_id: str,
    base_settings: dict,
    override_settings: dict | None,
    script: str,
    speed: float,
    audio_format: str,
    chars_needed: int,
):
    async with AsyncSessionLocal() as db:
        # Fetch objects
        job_result = await db.execute(select(GenerationJob).where(GenerationJob.id == uuid.UUID(job_id)))
        job = job_result.scalar_one()
        proj_result = await db.execute(select(Project).where(Project.id == uuid.UUID(project_id)))
        project = proj_result.scalar_one()
        user_result = await db.execute(select(User).where(User.id == uuid.UUID(user_id)))
        user = user_result.scalar_one()

        job.status = "processing"
        job.started_at = datetime.now(timezone.utc)
        await db.commit()

        try:
            final_settings = {**base_settings, **(override_settings or {})}

            # Parse emotion tags
            segments = parse_script(script)

            # Synthesize via ElevenLabs
            raw_chunks = await elevenlabs_client.synthesize_segments(
                segments=segments,
                provider_voice_id=voice_provider_id,
                base_voice_settings=final_settings,
                speed=speed,
            )

            job.chunks_total = len(raw_chunks)
            job.chunks_done = len(raw_chunks)
            await db.commit()

            # Stitch audio
            audio_bytes = await stitch_audio_chunks(raw_chunks)
            duration = await get_audio_duration(audio_bytes)

            # Upload to storage
            storage_path = storage_service.upload_audio(
                audio_bytes=audio_bytes,
                user_id=user_id,
                project_id=project_id,
                fmt=audio_format,
            )

            # Update project
            project.audio_storage_path = storage_path
            project.audio_duration_seconds = duration
            project.audio_format = audio_format
            project.status = "done"
            project.chars_used = chars_needed

            # Record usage
            await record_usage(
                db=db,
                user=user,
                chars_used=chars_needed,
                project_id=project.id,
                audio_duration=duration,
            )

            job.status = "done"
            job.completed_at = datetime.now(timezone.utc)
            await db.commit()

        except Exception as e:
            job.status = "failed"
            job.error_message = str(e)[:500]
            project.status = "failed"
            await db.commit()


@router.get("/{job_id}/status", response_model=JobStatusResponse)
async def get_job_status(
    job_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        jid = uuid.UUID(job_id)
    except ValueError:
        raise HTTPException(status_code=404, detail="Job not found.")

    result = await db.execute(select(GenerationJob).where(GenerationJob.id == jid, GenerationJob.user_id == user.id))
    job = result.scalar_one_or_none()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found.")

    audio_url = None
    if job.status == "done":
        proj_result = await db.execute(select(Project).where(Project.id == job.project_id))
        project = proj_result.scalar_one_or_none()
        if project and project.audio_storage_path:
            try:
                audio_url = storage_service.generate_presigned_url(project.audio_storage_path)
            except Exception:
                pass

    total = job.chunks_total or 1
    progress = job.chunks_done / total if total > 0 else 0.0

    return JobStatusResponse(
        job_id=str(job.id),
        status=job.status,
        progress=round(progress, 2),
        audio_url=audio_url,
        error="Voice generation failed. Please try again." if job.status == "failed" else None,
    )
'''

# ── routers/usage.py ──────────────────────────────────────────────────────────
files['app/routers/usage.py'] = '''
from datetime import datetime
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel
from app.database import get_db
from app.models.user import User
from app.middleware.auth import get_current_user
from app.services.usage_tracker import get_chars_used, get_chars_limit
from app.config import TIER_LIMITS

router = APIRouter(prefix="/usage", tags=["usage"])


class UsageResponse(BaseModel):
    chars_used: int
    chars_limit: int
    subscription_tier: str
    period_reset_at: datetime | None
    formats_available: list[str]


@router.get("/me", response_model=UsageResponse)
async def get_my_usage(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    used = await get_chars_used(db, user)
    limit = await get_chars_limit(user)
    tier = user.subscription_tier or "free"
    formats = TIER_LIMITS.get(tier, TIER_LIMITS["free"])["formats"]
    return UsageResponse(
        chars_used=used,
        chars_limit=limit,
        subscription_tier=tier,
        period_reset_at=user.period_reset_at,
        formats_available=formats,
    )
'''

# ── routers/auth.py ───────────────────────────────────────────────────────────
files['app/routers/auth.py'] = '''
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from app.models.user import User
from app.middleware.auth import get_current_user

router = APIRouter(prefix="/auth", tags=["auth"])


class MeResponse(BaseModel):
    id: str
    email: str | None
    display_name: str | None
    subscription_tier: str


@router.get("/me", response_model=MeResponse)
async def get_me(user: User = Depends(get_current_user)):
    return MeResponse(
        id=str(user.id),
        email=user.email,
        display_name=user.display_name,
        subscription_tier=user.subscription_tier or "free",
    )
'''

# ── routers/pronunciation.py ──────────────────────────────────────────────────
files['app/routers/pronunciation.py'] = '''
import uuid
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from app.database import get_db
from app.models.usage import PronunciationRule
from app.models.user import User
from app.middleware.auth import get_current_user

router = APIRouter(prefix="/pronunciation", tags=["pronunciation"])


class RuleCreate(BaseModel):
    word: str
    pronunciation: str


class RuleResponse(BaseModel):
    id: str
    word: str
    pronunciation: str


@router.get("", response_model=list[RuleResponse])
async def list_rules(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(PronunciationRule).where(PronunciationRule.user_id == user.id)
    )
    return [RuleResponse(id=str(r.id), word=r.word, pronunciation=r.pronunciation)
            for r in result.scalars().all()]


@router.post("", response_model=RuleResponse, status_code=201)
async def create_rule(
    body: RuleCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    rule = PronunciationRule(user_id=user.id, word=body.word.strip(), pronunciation=body.pronunciation.strip())
    db.add(rule)
    await db.commit()
    await db.refresh(rule)
    return RuleResponse(id=str(rule.id), word=rule.word, pronunciation=rule.pronunciation)


@router.delete("/{rule_id}", status_code=204)
async def delete_rule(
    rule_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        rid = uuid.UUID(rule_id)
    except ValueError:
        raise HTTPException(status_code=404, detail="Rule not found.")
    result = await db.execute(
        select(PronunciationRule).where(PronunciationRule.id == rid, PronunciationRule.user_id == user.id)
    )
    rule = result.scalar_one_or_none()
    if not rule:
        raise HTTPException(status_code=404, detail="Rule not found.")
    await db.delete(rule)
    await db.commit()
'''

# ── main.py ───────────────────────────────────────────────────────────────────
files['app/main.py'] = '''
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from app.config import settings
from app.routers import auth, voices, projects, generate, usage, pronunciation


@asynccontextmanager
async def lifespan(app: FastAPI):
    yield


app = FastAPI(
    title="12Labs API",
    version="1.0.0",
    description="Backend API for 12Labs AI Voiceover App",
    lifespan=lifespan,
    docs_url="/docs" if settings.debug else None,  # Hide docs in production
    redoc_url=None,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Rate limiting
limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# Routers
app.include_router(auth.router)
app.include_router(voices.router)
app.include_router(projects.router)
app.include_router(generate.router)
app.include_router(usage.router)
app.include_router(pronunciation.router)


@app.get("/health")
async def health():
    return {"status": "ok", "service": "12Labs API"}
'''

# ── app/routers/__init__.py ───────────────────────────────────────────────────
files['app/routers/__init__.py'] = ''

# write all files
for path, content in files.items():
    full = f'/data/12labs/backend/{path}'
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, 'w') as f:
        f.write(content.lstrip('\n'))
    print(f'wrote {full}')

print('DONE')
