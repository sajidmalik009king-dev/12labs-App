import re
from dataclasses import dataclass
from enum import Enum
from typing import Any


class SupportLevel(str, Enum):
    NATIVE = "native"          # ElevenLabs handles it natively
    APPROXIMATED = "approximated"  # We approximate via settings
    FALLBACK = "fallback"      # We insert silence / ignore
    UNSUPPORTED = "unsupported"


class SegmentType(str, Enum):
    TEXT = "text"
    ACTION = "action"


@dataclass
class Segment:
    type: SegmentType
    content: str = ""          # For TEXT segments
    tag: str = ""              # Original bracket tag (normalized)
    support: SupportLevel = SupportLevel.FALLBACK
    implementation: str = ""   # How it's implemented
    params: dict = None        # Extra params (duration_ms, settings, etc.)

    def to_dict(self) -> dict:
        d = {
            "type": self.type.value,
            "content": self.content,
            "tag": self.tag,
            "support": self.support.value if self.support else None,
            "implementation": self.implementation,
            "params": self.params or {},
        }
        return {k: v for k, v in d.items() if v is not None and v != ""}


# ElevenLabs capability map
# Keys: normalized lowercase tag text
EMOTION_CAPABILITIES: dict[str, dict[str, Any]] = {
    # Pauses — native via SSML break
    "pause":       {"support": SupportLevel.NATIVE, "impl": "ssml_break", "params": {"duration_ms": 500}},
    "short pause": {"support": SupportLevel.NATIVE, "impl": "ssml_break", "params": {"duration_ms": 300}},
    "long pause":  {"support": SupportLevel.NATIVE, "impl": "ssml_break", "params": {"duration_ms": 1500}},

    # Delivery approximated via voice settings
    "whispers":    {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.25, "similarity_boost": 0.9, "style": 0.8}},
    "whisper":     {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.25, "similarity_boost": 0.9, "style": 0.8}},
    "softly":      {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.7, "similarity_boost": 0.8, "style": 0.3}},
    "softly":      {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.7, "similarity_boost": 0.8, "style": 0.3}},
    "quietly":     {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.6, "similarity_boost": 0.75, "style": 0.2}},
    "slowly":      {"support": SupportLevel.APPROXIMATED, "impl": "speed_override",
                    "params": {"speed": 0.75}},
    "firmly":      {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.85, "similarity_boost": 0.9, "style": 0.5}},
    "dramatically":{"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.2, "similarity_boost": 0.95, "style": 0.95}},

    # Emotions — approximated
    "excited":     {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.15, "similarity_boost": 0.95, "style": 0.9}},
    "happy":       {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.4, "similarity_boost": 0.9, "style": 0.7}},
    "sad":         {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.8, "similarity_boost": 0.6, "style": 0.2}},
    "sadly":       {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.8, "similarity_boost": 0.6, "style": 0.2}},
    "angry":       {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.1, "similarity_boost": 0.95, "style": 0.95}},
    "angrily":     {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.1, "similarity_boost": 0.95, "style": 0.95}},
    "nervous":     {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.3, "similarity_boost": 0.85, "style": 0.6}},
    "scared":      {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.2, "similarity_boost": 0.9, "style": 0.75}},
    "confused":    {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.4, "similarity_boost": 0.8, "style": 0.5}},
    "shocked":     {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.1, "similarity_boost": 0.95, "style": 0.9}},
    "serious":     {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.9, "similarity_boost": 0.85, "style": 0.1}},
    "calm":        {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.95, "similarity_boost": 0.75, "style": 0.05}},
    "confident":   {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.8, "similarity_boost": 0.95, "style": 0.5}},
    "concerned":   {"support": SupportLevel.APPROXIMATED, "impl": "settings_override",
                    "params": {"stability": 0.6, "similarity_boost": 0.8, "style": 0.4}},

    # Vocal actions — fallback (insert short pause at minimum)
    "chuckles":    {"support": SupportLevel.FALLBACK, "impl": "ssml_break", "params": {"duration_ms": 400}},
    "laughs":      {"support": SupportLevel.FALLBACK, "impl": "ssml_break", "params": {"duration_ms": 600}},
    "laughs softly": {"support": SupportLevel.FALLBACK, "impl": "ssml_break", "params": {"duration_ms": 500}},
    "sighs":       {"support": SupportLevel.FALLBACK, "impl": "ssml_break", "params": {"duration_ms": 700}},
    "deep breath": {"support": SupportLevel.FALLBACK, "impl": "ssml_break", "params": {"duration_ms": 1000}},
    "gasps":       {"support": SupportLevel.FALLBACK, "impl": "ssml_break", "params": {"duration_ms": 300}},
    "clears throat": {"support": SupportLevel.FALLBACK, "impl": "ssml_break", "params": {"duration_ms": 400}},
}

BRACKET_RE = re.compile(r"\[([^\]]+)\]")


def parse_script(script: str) -> list[Segment]:
    """
    Parse a script with emotion tags into a list of Segment objects.
    Text between tags becomes TEXT segments.
    Bracket content becomes ACTION segments.
    """
    segments: list[Segment] = []
    last_end = 0

    for match in BRACKET_RE.finditer(script):
        # Text before this bracket
        text_before = script[last_end:match.start()].strip()
        if text_before:
            segments.append(Segment(type=SegmentType.TEXT, content=text_before))

        tag_raw = match.group(1).strip().lower()
        cap = EMOTION_CAPABILITIES.get(tag_raw)
        if cap:
            seg = Segment(
                type=SegmentType.ACTION,
                tag=tag_raw,
                support=cap["support"],
                implementation=cap["impl"],
                params=cap["params"].copy(),
            )
        else:
            # Unknown tag — treat as a short pause fallback, do NOT speak it
            seg = Segment(
                type=SegmentType.ACTION,
                tag=tag_raw,
                support=SupportLevel.FALLBACK,
                implementation="ssml_break",
                params={"duration_ms": 300},
            )
        segments.append(seg)
        last_end = match.end()

    # Remaining text after last bracket
    remaining = script[last_end:].strip()
    if remaining:
        segments.append(Segment(type=SegmentType.TEXT, content=remaining))

    return segments


def segments_to_dict(segments: list[Segment]) -> list[dict]:
    return [s.to_dict() for s in segments]
