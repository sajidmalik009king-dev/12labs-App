from datetime import datetime, timezone
from dateutil.relativedelta import relativedelta
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from app.models.user import User
from app.models.usage import UsageEvent
from app.config import settings, TIER_LIMITS


async def get_chars_limit(user: User) -> int:
    tier = user.subscription_tier or "free"
    return TIER_LIMITS.get(tier, TIER_LIMITS["free"])["chars_per_month"]


async def get_chars_used(db: AsyncSession, user: User) -> int:
    # Reset period if needed
    now = datetime.now(timezone.utc)
    if user.period_reset_at is None or now >= user.period_reset_at:
        user.chars_used_this_period = 0
        user.period_reset_at = (now + relativedelta(months=1)).replace(
            hour=0, minute=0, second=0, microsecond=0
        )
        await db.commit()
        await db.refresh(user)
    return user.chars_used_this_period


async def check_usage(
    db: AsyncSession,
    user: User,
    chars_needed: int,
) -> tuple[bool, int, int]:
    """Returns (ok, chars_used, chars_limit)."""
    used = await get_chars_used(db, user)
    limit = await get_chars_limit(user)
    ok = (used + chars_needed) <= limit
    return ok, used, limit


async def record_usage(
    db: AsyncSession,
    user: User,
    chars_used: int,
    project_id=None,
    audio_duration: float | None = None,
    provider: str = "elevenlabs",
):
    event = UsageEvent(
        user_id=user.id,
        project_id=project_id,
        chars_used=chars_used,
        audio_duration_seconds=audio_duration,
        provider=provider,
    )
    db.add(event)
    user.chars_used_this_period = (user.chars_used_this_period or 0) + chars_used
    await db.commit()
