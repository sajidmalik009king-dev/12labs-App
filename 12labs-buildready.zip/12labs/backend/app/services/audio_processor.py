import asyncio
import io
import subprocess
import tempfile
import os
from pathlib import Path


async def generate_silence_bytes(duration_ms: int) -> bytes:
    """Generate PCM silence of given duration, encoded as MP3."""
    cmd = [
        "ffmpeg", "-f", "lavfi",
        "-i", f"anullsrc=r=44100:cl=mono",
        "-t", str(duration_ms / 1000),
        "-acodec", "libmp3lame",
        "-ab", "128k",
        "-f", "mp3",
        "pipe:1"
    ]
    proc = await asyncio.create_subprocess_exec(
        *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await proc.communicate()
    if proc.returncode != 0:
        raise RuntimeError(f"ffmpeg silence error: {stderr.decode()[:200]}")
    return stdout


async def stitch_audio_chunks(chunks: list[tuple[str, bytes | int]]) -> bytes:
    """
    Stitch (type, data) chunks into one MP3.
    type = "audio" -> bytes of MP3
    type = "silence" -> int milliseconds
    """
    with tempfile.TemporaryDirectory() as tmpdir:
        segment_files = []
        for i, (chunk_type, data) in enumerate(chunks):
            path = os.path.join(tmpdir, f"seg_{i:04d}.mp3")
            if chunk_type == "audio":
                with open(path, "wb") as f:
                    f.write(data)
            elif chunk_type == "silence":
                silence = await generate_silence_bytes(int(data))
                with open(path, "wb") as f:
                    f.write(silence)
            segment_files.append(path)

        if not segment_files:
            return b""

        if len(segment_files) == 1:
            with open(segment_files[0], "rb") as f:
                return f.read()

        # Write concat list file
        list_path = os.path.join(tmpdir, "concat.txt")
        with open(list_path, "w") as f:
            for p in segment_files:
                f.write(f"file '{p}'
")

        output_path = os.path.join(tmpdir, "output.mp3")
        cmd = [
            "ffmpeg", "-f", "concat",
            "-safe", "0",
            "-i", list_path,
            "-c", "copy",
            output_path
        ]
        proc = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        stdout, stderr = await proc.communicate()
        if proc.returncode != 0:
            raise RuntimeError(f"ffmpeg concat error: {stderr.decode()[:500]}")

        with open(output_path, "rb") as f:
            return f.read()


async def get_audio_duration(audio_bytes: bytes) -> float:
    """Return duration in seconds of an MP3 byte string."""
    with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as tmp:
        tmp.write(audio_bytes)
        tmp_path = tmp.name
    try:
        cmd = [
            "ffprobe", "-v", "quiet",
            "-show_entries", "format=duration",
            "-of", "csv=p=0",
            tmp_path
        ]
        proc = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        stdout, _ = await proc.communicate()
        return float(stdout.decode().strip() or "0")
    finally:
        os.unlink(tmp_path)


def chunk_script(script: str, max_chars: int = 2500) -> list[str]:
    """
    Split a long script into chunks <= max_chars,
    splitting on paragraph > sentence > word boundaries.
    Preserves [emotion tags] within their owning paragraph.
    """
    paragraphs = [p.strip() for p in script.split("

") if p.strip()]
    chunks = []
    current = ""

    for para in paragraphs:
        candidate = (current + "

" + para).strip() if current else para
        if len(candidate) <= max_chars:
            current = candidate
        else:
            # Paragraph itself too long — split on sentences
            if current:
                chunks.append(current)
                current = ""
            sentences = _split_sentences(para)
            for sent in sentences:
                candidate2 = (current + " " + sent).strip() if current else sent
                if len(candidate2) <= max_chars:
                    current = candidate2
                else:
                    if current:
                        chunks.append(current)
                    current = sent  # May still be long — accept as-is
    if current:
        chunks.append(current)
    return chunks


import re
_SENT_RE = re.compile(r'(?<=[.!?])\s+')


def _split_sentences(text: str) -> list[str]:
    return [s.strip() for s in _SENT_RE.split(text) if s.strip()]
