import io
import os
import uuid
from datetime import datetime
import boto3
from botocore.config import Config
from botocore.exceptions import ClientError
from app.config import settings


class StorageService:
    def __init__(self):
        self._client = None

    def _get_client(self):
        if self._client is None:
            kwargs = dict(
                region_name=settings.s3_region,
                aws_access_key_id=settings.s3_access_key,
                aws_secret_access_key=settings.s3_secret_key,
            )
            if settings.s3_endpoint_url:
                kwargs["endpoint_url"] = settings.s3_endpoint_url
            self._client = boto3.client("s3", **kwargs, config=Config(signature_version="s3v4"))
        return self._client

    def upload_audio(
        self,
        audio_bytes: bytes,
        user_id: str,
        project_id: str,
        fmt: str = "mp3",
    ) -> str:
        """Upload audio bytes and return the storage path (key)."""
        key = f"audio/{user_id}/{project_id}/voiceover.{fmt}"
        content_type = "audio/mpeg" if fmt == "mp3" else "audio/wav"
        self._get_client().put_object(
            Bucket=settings.s3_bucket,
            Key=key,
            Body=audio_bytes,
            ContentType=content_type,
        )
        return key

    def upload_preview(
        self,
        audio_bytes: bytes,
        voice_id: str,
    ) -> str:
        """Upload a voice preview file and return storage path."""
        key = f"voices/previews/{voice_id}/preview.mp3"
        self._get_client().put_object(
            Bucket=settings.s3_bucket,
            Key=key,
            Body=audio_bytes,
            ContentType="audio/mpeg",
        )
        return key

    def generate_presigned_url(self, storage_path: str, expiry: int | None = None) -> str:
        """Generate a pre-signed URL for a stored object."""
        if expiry is None:
            expiry = settings.audio_url_expiry
        return self._get_client().generate_presigned_url(
            "get_object",
            Params={"Bucket": settings.s3_bucket, "Key": storage_path},
            ExpiresIn=expiry,
        )

    def delete_object(self, storage_path: str):
        try:
            self._get_client().delete_object(Bucket=settings.s3_bucket, Key=storage_path)
        except ClientError:
            pass  # Already deleted or doesn't exist


storage_service = StorageService()
