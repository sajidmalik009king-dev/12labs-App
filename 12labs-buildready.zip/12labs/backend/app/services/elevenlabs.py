import asyncio
import httpx
import json
from typing import AsyncIterator
from app.config import settings
from app.services.emotion_parser import Segment, SegmentType, SupportLevel


ELEVENLABS_TTS_URL = "{base}/text-to-speech/{voice_id}"
ELEVENLABS_MODELS = {
    "default": "eleven_turbo_v2_5",  # Fast, high quality
    "multilingual": "eleven_multilingual_v2",
}


class ElevenLabsClient:
    def __init__(self):
        self.api_key = settings.elevenlabs_api_key
        self.base_url = settings.elevenlabs_base_url

    def _headers(self) -> dict:
        return {
            "xi-api-key": self.api_key,
            "Content-Type": "application/json",
            "Accept": "audio/mpeg",
        }

    def _build_request(
        self,
        text: str,
        voice_settings: dict,
        speed: float = 1.0,
        output_format: str = "mp3_44100_128",
    ) -> dict:
        return {
            "text": text,
            "model_id": ELEVENLABS_MODELS["default"],
            "voice_settings": {
                "stability": voice_settings.get("stability", 0.5),
                "similarity_boost": voice_settings.get("similarity_boost", 0.8),
                "style": voice_settings.get("style", 0.0),
                "use_speaker_boost": voice_settings.get("use_speaker_boost", True),
                "speed": speed,
            },
            "output_format": output_format,
        }

    async def synthesize_chunk(
        self,
        text: str,
        provider_voice_id: str,
        voice_settings: dict,
        speed: float = 1.0,
        output_format: str = "mp3_44100_128",
    ) -> bytes:
        """Synthesize a single text chunk, returning raw audio bytes."""
        url = f"{self.base_url}/text-to-speech/{provider_voice_id}"
        payload = self._build_request(text, voice_settings, speed, output_format)

        async with httpx.AsyncClient(timeout=120.0) as client:
            resp = await client.post(url, headers=self._headers(), json=payload)
            if resp.status_code == 422:
                raise ValueError(f"ElevenLabs validation error: {resp.text}")
            if resp.status_code == 429:
                raise RuntimeError("ElevenLabs rate limit exceeded. Please try again.")
            resp.raise_for_status()
            return resp.content

    async def synthesize_segments(
        self,
        segments: list[Segment],
        provider_voice_id: str,
        base_voice_settings: dict,
        speed: float = 1.0,
    ) -> list[tuple[str, bytes | int]]:
        """
        Process segments and return a list of (type, data) tuples:
        - ("audio", bytes)  — synthesized audio
        - ("silence", ms)   — duration in ms to insert as silence
        """
        results = []
        current_text = []
        current_settings = base_voice_settings.copy()
        current_speed = speed
        pending_settings_override = None
        pending_speed_override = None

        async def flush_text():
            nonlocal current_text
            combined = " ".join(current_text).strip()
            if combined:
                s = pending_settings_override or current_settings
                sp = pending_speed_override or current_speed
                audio = await self.synthesize_chunk(
                    combined, provider_voice_id, s, sp
                )
                results.append(("audio", audio))
                current_text = []

        for seg in segments:
            if seg.type == SegmentType.TEXT:
                current_text.append(seg.content)
            elif seg.type == SegmentType.ACTION:
                if seg.implementation == "ssml_break":
                    # Flush accumulated text first
                    await flush_text()
                    results.append(("silence", seg.params.get("duration_ms", 500)))
                elif seg.implementation == "settings_override":
                    # Flush current text, then next text uses overridden settings
                    await flush_text()
                    pending_settings_override = {**base_voice_settings, **seg.params}
                elif seg.implementation == "speed_override":
                    await flush_text()
                    pending_speed_override = seg.params.get("speed", 0.75)

        await flush_text()
        return results


elevenlabs_client = ElevenLabsClient()
