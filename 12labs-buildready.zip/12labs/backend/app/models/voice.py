import uuid
from datetime import datetime
from sqlalchemy import String, Boolean, Integer, Text, func
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.dialects.postgresql import UUID, JSONB
from app.database import Base


class Voice(Base):
    __tablename__ = "voices"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    display_name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    accent: Mapped[str | None] = mapped_column(String(100))
    provider: Mapped[str] = mapped_column(String(50), default="elevenlabs")
    provider_voice_id: Mapped[str] = mapped_column(String(255), nullable=False)  # NEVER sent to client
    preview_storage_path: Mapped[str | None] = mapped_column(Text)  # internal storage path
    voice_settings: Mapped[dict | None] = mapped_column(JSONB)  # {stability, similarity_boost, style, use_speaker_boost}
    tier_required: Mapped[str] = mapped_column(String(20), default="free")  # free|creator|pro
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(server_default=func.now(), onupdate=func.now())
