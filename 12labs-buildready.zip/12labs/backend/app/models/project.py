import uuid
from datetime import datetime
from sqlalchemy import String, Float, Text, ForeignKey, func
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import UUID, JSONB
from app.database import Base


class Project(Base):
    __tablename__ = "projects"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(255), default="Untitled Project")
    script: Mapped[str] = mapped_column(Text, nullable=False)
    voice_id: Mapped[uuid.UUID | None] = mapped_column(UUID(as_uuid=True), ForeignKey("voices.id", ondelete="SET NULL"))
    voice_settings_override: Mapped[dict | None] = mapped_column(JSONB)
    speed: Mapped[float] = mapped_column(Float, default=1.0)
    emotion_tags: Mapped[list | None] = mapped_column(JSONB)
    audio_storage_path: Mapped[str | None] = mapped_column(Text)
    audio_duration_seconds: Mapped[float | None] = mapped_column(Float)
    audio_format: Mapped[str] = mapped_column(String(10), default="mp3")
    status: Mapped[str] = mapped_column(String(20), default="draft")  # draft|generating|done|failed
    chars_used: Mapped[int | None] = mapped_column()
    created_at: Mapped[datetime] = mapped_column(server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(server_default=func.now(), onupdate=func.now())

    user: Mapped["User"] = relationship("User", back_populates="projects")
    voice: Mapped["Voice | None"] = relationship("Voice")
    generation_jobs: Mapped[list["GenerationJob"]] = relationship("GenerationJob", back_populates="project", cascade="all, delete-orphan")


class GenerationJob(Base):
    __tablename__ = "generation_jobs"

    id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    project_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("projects.id", ondelete="CASCADE"))
    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"))
    status: Mapped[str] = mapped_column(String(20), default="pending")  # pending|processing|done|failed
    chunks_total: Mapped[int | None] = mapped_column()
    chunks_done: Mapped[int] = mapped_column(default=0)
    error_message: Mapped[str | None] = mapped_column(Text)
    started_at: Mapped[datetime | None] = mapped_column()
    completed_at: Mapped[datetime | None] = mapped_column()
    created_at: Mapped[datetime] = mapped_column(server_default=func.now())

    project: Mapped["Project"] = relationship("Project", back_populates="generation_jobs")
