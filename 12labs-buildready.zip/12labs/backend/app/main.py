from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from app.config import settings
from app.routers import auth, voices, projects, generate, usage, pronunciation


@asynccontextmanager
async def lifespan(app: FastAPI):
    yield


app = FastAPI(
    title="12Labs API",
    version="1.0.0",
    description="Backend API for 12Labs AI Voiceover App",
    lifespan=lifespan,
    docs_url="/docs" if settings.debug else None,  # Hide docs in production
    redoc_url=None,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Rate limiting
limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# Routers
app.include_router(auth.router)
app.include_router(voices.router)
app.include_router(projects.router)
app.include_router(generate.router)
app.include_router(usage.router)
app.include_router(pronunciation.router)


@app.get("/health")
async def health():
    return {"status": "ok", "service": "12Labs API"}
