import uuid
import asyncio
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from app.database import get_db, AsyncSessionLocal
from app.models.project import Project, GenerationJob
from app.models.voice import Voice
from app.models.user import User
from app.middleware.auth import get_current_user
from app.services.emotion_parser import parse_script
from app.services.elevenlabs import elevenlabs_client
from app.services.audio_processor import stitch_audio_chunks, get_audio_duration, chunk_script
from app.services.storage import storage_service
from app.services.usage_tracker import check_usage, record_usage
from app.config import settings, TIER_LIMITS

router = APIRouter(prefix="/generate", tags=["generate"])


class GenerateRequest(BaseModel):
    project_id: str
    voice_id: str
    script: str
    speed: float = 1.0
    audio_format: str = "mp3"  # mp3 | wav
    voice_settings_override: dict | None = None


class GenerateResponse(BaseModel):
    job_id: str
    status: str
    message: str


class JobStatusResponse(BaseModel):
    job_id: str
    status: str
    progress: float
    audio_url: str | None
    error: str | None


@router.post("", response_model=GenerateResponse)
async def start_generation(
    body: GenerateRequest,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    # Validate format access
    allowed_formats = TIER_LIMITS.get(user.subscription_tier, TIER_LIMITS["free"])["formats"]
    if body.audio_format not in allowed_formats:
        raise HTTPException(
            status_code=403,
            detail=f"Your plan does not support {body.audio_format.upper()} export. Upgrade to access this feature.",
        )

    # Validate project ownership
    try:
        pid = uuid.UUID(body.project_id)
    except ValueError:
        raise HTTPException(status_code=404, detail="Project not found.")
    result = await db.execute(select(Project).where(Project.id == pid, Project.user_id == user.id))
    project = result.scalar_one_or_none()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found.")

    # Validate voice
    try:
        vid = uuid.UUID(body.voice_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid voice ID.")
    v_result = await db.execute(select(Voice).where(Voice.id == vid, Voice.is_active == True))
    voice = v_result.scalar_one_or_none()
    if not voice:
        raise HTTPException(status_code=404, detail="Voice not found or unavailable.")

    # Check voice tier access
    tier_order = {"free": 0, "creator": 1, "pro": 2}
    if tier_order.get(voice.tier_required, 0) > tier_order.get(user.subscription_tier, 0):
        raise HTTPException(status_code=403, detail="This voice requires a higher subscription tier.")

    # Check usage
    clean_script = body.script.strip()
    chars_needed = len(clean_script)
    ok, chars_used, chars_limit = await check_usage(db, user, chars_needed)
    if not ok:
        raise HTTPException(
            status_code=402,
            detail=f"Character limit exceeded. Used: {chars_used}/{chars_limit}. Upgrade for more.",
        )

    # Create generation job
    job = GenerationJob(
        project_id=project.id,
        user_id=user.id,
        status="pending",
    )
    db.add(job)
    project.status = "generating"
    await db.commit()
    await db.refresh(job)

    # Fire background task
    background_tasks.add_task(
        _run_generation,
        job_id=str(job.id),
        project_id=str(project.id),
        user_id=str(user.id),
        voice_provider_id=voice.provider_voice_id,
        base_settings=voice.voice_settings or {},
        override_settings=body.voice_settings_override,
        script=clean_script,
        speed=body.speed,
        audio_format=body.audio_format,
        chars_needed=chars_needed,
    )

    return GenerateResponse(
        job_id=str(job.id),
        status="pending",
        message="Generation started.",
    )


async def _run_generation(
    job_id: str,
    project_id: str,
    user_id: str,
    voice_provider_id: str,
    base_settings: dict,
    override_settings: dict | None,
    script: str,
    speed: float,
    audio_format: str,
    chars_needed: int,
):
    async with AsyncSessionLocal() as db:
        # Fetch objects
        job_result = await db.execute(select(GenerationJob).where(GenerationJob.id == uuid.UUID(job_id)))
        job = job_result.scalar_one()
        proj_result = await db.execute(select(Project).where(Project.id == uuid.UUID(project_id)))
        project = proj_result.scalar_one()
        user_result = await db.execute(select(User).where(User.id == uuid.UUID(user_id)))
        user = user_result.scalar_one()

        job.status = "processing"
        job.started_at = datetime.now(timezone.utc)
        await db.commit()

        try:
            final_settings = {**base_settings, **(override_settings or {})}

            # Parse emotion tags
            segments = parse_script(script)

            # Synthesize via ElevenLabs
            raw_chunks = await elevenlabs_client.synthesize_segments(
                segments=segments,
                provider_voice_id=voice_provider_id,
                base_voice_settings=final_settings,
                speed=speed,
            )

            job.chunks_total = len(raw_chunks)
            job.chunks_done = len(raw_chunks)
            await db.commit()

            # Stitch audio
            audio_bytes = await stitch_audio_chunks(raw_chunks)
            duration = await get_audio_duration(audio_bytes)

            # Upload to storage
            storage_path = storage_service.upload_audio(
                audio_bytes=audio_bytes,
                user_id=user_id,
                project_id=project_id,
                fmt=audio_format,
            )

            # Update project
            project.audio_storage_path = storage_path
            project.audio_duration_seconds = duration
            project.audio_format = audio_format
            project.status = "done"
            project.chars_used = chars_needed

            # Record usage
            await record_usage(
                db=db,
                user=user,
                chars_used=chars_needed,
                project_id=project.id,
                audio_duration=duration,
            )

            job.status = "done"
            job.completed_at = datetime.now(timezone.utc)
            await db.commit()

        except Exception as e:
            job.status = "failed"
            job.error_message = str(e)[:500]
            project.status = "failed"
            await db.commit()


@router.get("/{job_id}/status", response_model=JobStatusResponse)
async def get_job_status(
    job_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        jid = uuid.UUID(job_id)
    except ValueError:
        raise HTTPException(status_code=404, detail="Job not found.")

    result = await db.execute(select(GenerationJob).where(GenerationJob.id == jid, GenerationJob.user_id == user.id))
    job = result.scalar_one_or_none()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found.")

    audio_url = None
    if job.status == "done":
        proj_result = await db.execute(select(Project).where(Project.id == job.project_id))
        project = proj_result.scalar_one_or_none()
        if project and project.audio_storage_path:
            try:
                audio_url = storage_service.generate_presigned_url(project.audio_storage_path)
            except Exception:
                pass

    total = job.chunks_total or 1
    progress = job.chunks_done / total if total > 0 else 0.0

    return JobStatusResponse(
        job_id=str(job.id),
        status=job.status,
        progress=round(progress, 2),
        audio_url=audio_url,
        error="Voice generation failed. Please try again." if job.status == "failed" else None,
    )
