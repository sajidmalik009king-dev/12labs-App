import uuid
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import RedirectResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from app.database import get_db
from app.models.voice import Voice
from app.models.user import User
from app.middleware.auth import get_current_user
from app.services.storage import storage_service
from app.config import settings

router = APIRouter(prefix="/voices", tags=["voices"])


class VoiceResponse(BaseModel):
    id: str
    display_name: str
    description: str | None
    accent: str | None
    tier_required: str
    preview_url: str | None  # signed URL — never the storage path directly

    class Config:
        from_attributes = True


@router.get("", response_model=list[VoiceResponse])
async def list_voices(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(Voice)
        .where(Voice.is_active == True)
        .order_by(Voice.sort_order, Voice.display_name)
    )
    voices = result.scalars().all()

    out = []
    for v in voices:
        preview_url = None
        if v.preview_storage_path:
            try:
                preview_url = storage_service.generate_presigned_url(
                    v.preview_storage_path,
                    expiry=settings.preview_url_expiry,
                )
            except Exception:
                pass
        out.append(VoiceResponse(
            id=str(v.id),
            display_name=v.display_name,
            description=v.description,
            accent=v.accent,
            tier_required=v.tier_required,
            preview_url=preview_url,
        ))
    return out
