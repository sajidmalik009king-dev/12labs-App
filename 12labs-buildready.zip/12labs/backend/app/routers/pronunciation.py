import uuid
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from app.database import get_db
from app.models.usage import PronunciationRule
from app.models.user import User
from app.middleware.auth import get_current_user

router = APIRouter(prefix="/pronunciation", tags=["pronunciation"])


class RuleCreate(BaseModel):
    word: str
    pronunciation: str


class RuleResponse(BaseModel):
    id: str
    word: str
    pronunciation: str


@router.get("", response_model=list[RuleResponse])
async def list_rules(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(PronunciationRule).where(PronunciationRule.user_id == user.id)
    )
    return [RuleResponse(id=str(r.id), word=r.word, pronunciation=r.pronunciation)
            for r in result.scalars().all()]


@router.post("", response_model=RuleResponse, status_code=201)
async def create_rule(
    body: RuleCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    rule = PronunciationRule(user_id=user.id, word=body.word.strip(), pronunciation=body.pronunciation.strip())
    db.add(rule)
    await db.commit()
    await db.refresh(rule)
    return RuleResponse(id=str(rule.id), word=rule.word, pronunciation=rule.pronunciation)


@router.delete("/{rule_id}", status_code=204)
async def delete_rule(
    rule_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    try:
        rid = uuid.UUID(rule_id)
    except ValueError:
        raise HTTPException(status_code=404, detail="Rule not found.")
    result = await db.execute(
        select(PronunciationRule).where(PronunciationRule.id == rid, PronunciationRule.user_id == user.id)
    )
    rule = result.scalar_one_or_none()
    if not rule:
        raise HTTPException(status_code=404, detail="Rule not found.")
    await db.delete(rule)
    await db.commit()
