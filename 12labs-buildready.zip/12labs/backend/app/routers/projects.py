import uuid
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from app.database import get_db
from app.models.project import Project
from app.models.user import User
from app.middleware.auth import get_current_user
from app.services.storage import storage_service

router = APIRouter(prefix="/projects", tags=["projects"])


class ProjectCreate(BaseModel):
    name: str = "Untitled Project"
    script: str = ""
    voice_id: str | None = None
    speed: float = 1.0
    audio_format: str = "mp3"


class ProjectUpdate(BaseModel):
    name: str | None = None
    script: str | None = None
    voice_id: str | None = None
    speed: float | None = None


class ProjectResponse(BaseModel):
    id: str
    name: str
    script: str
    voice_id: str | None
    speed: float
    audio_format: str
    status: str
    audio_url: str | None
    audio_duration_seconds: float | None
    chars_used: int | None
    created_at: datetime
    updated_at: datetime


def _project_to_response(p: Project) -> ProjectResponse:
    audio_url = None
    if p.audio_storage_path and p.status == "done":
        try:
            audio_url = storage_service.generate_presigned_url(p.audio_storage_path)
        except Exception:
            pass
    return ProjectResponse(
        id=str(p.id),
        name=p.name,
        script=p.script,
        voice_id=str(p.voice_id) if p.voice_id else None,
        speed=p.speed,
        audio_format=p.audio_format,
        status=p.status,
        audio_url=audio_url,
        audio_duration_seconds=p.audio_duration_seconds,
        chars_used=p.chars_used,
        created_at=p.created_at,
        updated_at=p.updated_at,
    )


@router.get("", response_model=list[ProjectResponse])
async def list_projects(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
    limit: int = 50,
    offset: int = 0,
):
    result = await db.execute(
        select(Project)
        .where(Project.user_id == user.id)
        .order_by(Project.updated_at.desc())
        .limit(limit)
        .offset(offset)
    )
    projects = result.scalars().all()
    return [_project_to_response(p) for p in projects]


@router.post("", response_model=ProjectResponse, status_code=201)
async def create_project(
    body: ProjectCreate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    project = Project(
        user_id=user.id,
        name=body.name,
        script=body.script,
        voice_id=uuid.UUID(body.voice_id) if body.voice_id else None,
        speed=body.speed,
        audio_format=body.audio_format,
    )
    db.add(project)
    await db.commit()
    await db.refresh(project)
    return _project_to_response(project)


@router.get("/{project_id}", response_model=ProjectResponse)
async def get_project(
    project_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    p = await _get_or_404(db, project_id, user.id)
    return _project_to_response(p)


@router.put("/{project_id}", response_model=ProjectResponse)
async def update_project(
    project_id: str,
    body: ProjectUpdate,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    p = await _get_or_404(db, project_id, user.id)
    if body.name is not None:
        p.name = body.name
    if body.script is not None:
        p.script = body.script
    if body.voice_id is not None:
        p.voice_id = uuid.UUID(body.voice_id)
    if body.speed is not None:
        p.speed = body.speed
    await db.commit()
    await db.refresh(p)
    return _project_to_response(p)


@router.delete("/{project_id}", status_code=204)
async def delete_project(
    project_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    p = await _get_or_404(db, project_id, user.id)
    if p.audio_storage_path:
        try:
            storage_service.delete_object(p.audio_storage_path)
        except Exception:
            pass
    await db.delete(p)
    await db.commit()


@router.post("/{project_id}/duplicate", response_model=ProjectResponse, status_code=201)
async def duplicate_project(
    project_id: str,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    p = await _get_or_404(db, project_id, user.id)
    new_p = Project(
        user_id=user.id,
        name=p.name + " (Copy)",
        script=p.script,
        voice_id=p.voice_id,
        speed=p.speed,
        audio_format=p.audio_format,
        status="draft",
    )
    db.add(new_p)
    await db.commit()
    await db.refresh(new_p)
    return _project_to_response(new_p)


async def _get_or_404(db: AsyncSession, project_id: str, user_id) -> Project:
    try:
        pid = uuid.UUID(project_id)
    except ValueError:
        raise HTTPException(status_code=404, detail="Project not found.")
    result = await db.execute(
        select(Project).where(Project.id == pid, Project.user_id == user_id)
    )
    p = result.scalar_one_or_none()
    if not p:
        raise HTTPException(status_code=404, detail="Project not found.")
    return p
