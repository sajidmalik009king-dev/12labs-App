from datetime import datetime
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel
from app.database import get_db
from app.models.user import User
from app.middleware.auth import get_current_user
from app.services.usage_tracker import get_chars_used, get_chars_limit
from app.config import TIER_LIMITS

router = APIRouter(prefix="/usage", tags=["usage"])


class UsageResponse(BaseModel):
    chars_used: int
    chars_limit: int
    subscription_tier: str
    period_reset_at: datetime | None
    formats_available: list[str]


@router.get("/me", response_model=UsageResponse)
async def get_my_usage(
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    used = await get_chars_used(db, user)
    limit = await get_chars_limit(user)
    tier = user.subscription_tier or "free"
    formats = TIER_LIMITS.get(tier, TIER_LIMITS["free"])["formats"]
    return UsageResponse(
        chars_used=used,
        chars_limit=limit,
        subscription_tier=tier,
        period_reset_at=user.period_reset_at,
        formats_available=formats,
    )
