from pydantic_settings import BaseSettings
from typing import Optional
import os


class Settings(BaseSettings):
    # App
    app_name: str = "12Labs API"
    debug: bool = False
    secret_key: str = "change-me-in-production"

    # Database
    database_url: str = "postgresql://twelvelabs:twelvelabs@localhost:5432/twelvelabs"

    # Redis
    redis_url: str = "redis://localhost:6379"

    # ElevenLabs
    elevenlabs_api_key: str = ""
    elevenlabs_base_url: str = "https://api.elevenlabs.io/v1"

    # Firebase
    firebase_project_id: str = ""
    firebase_service_account_json: str = ""  # JSON string or path

    # Storage (S3-compatible)
    storage_provider: str = "s3"  # s3 | gcs | local
    s3_bucket: str = "twelvelabs-audio"
    s3_region: str = "us-east-1"
    s3_access_key: str = ""
    s3_secret_key: str = ""
    s3_endpoint_url: Optional[str] = None  # For S3-compatible like Cloudflare R2
    s3_public_base_url: str = ""

    # Signed URL expiry (seconds)
    audio_url_expiry: int = 900  # 15 minutes
    preview_url_expiry: int = 3600  # 1 hour

    # Usage limits per tier
    free_chars_per_month: int = 10_000
    creator_chars_per_month: int = 100_000
    pro_chars_per_month: int = 500_000

    # Script chunking
    max_chars_per_chunk: int = 2500  # ElevenLabs safe limit

    # Rate limiting
    rate_limit_per_minute: int = 10
    rate_limit_burst: int = 20

    # Google Play
    google_play_package_name: str = "com.twelvelabs.app"

    # CORS
    allowed_origins: list = ["*"]

    class Config:
        env_file = ".env"
        case_sensitive = False


settings = Settings()


TIER_LIMITS = {
    "free": {"chars_per_month": settings.free_chars_per_month, "formats": ["mp3"]},
    "creator": {"chars_per_month": settings.creator_chars_per_month, "formats": ["mp3", "wav"]},
    "pro": {"chars_per_month": settings.pro_chars_per_month, "formats": ["mp3", "wav"]},
}
